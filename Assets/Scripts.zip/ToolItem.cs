using System.Collections;
using UnityEngine;

public enum ToolKind { Knife, CuttingBoard, Wok, Pot, Ladle, Spatula, Spoon, Chopsticks, Bowl, MeasuringCup, Strainer, SmallDish, Rag, Cloth, PaperTowel, Whisk, MeasuringSpoon }

public class ToolItem : Carryable
{
    [SerializeField] private ToolKind kind;

    public ToolKind Kind => kind;

    private bool CanWrap => kind == ToolKind.PaperTowel || kind == ToolKind.Cloth || kind == ToolKind.Rag;

    /// <summary>Same towel/cloth/rag check as CanWrap, exposed publicly so other
    /// Interactables (the sink, a bowl) can offer this tool a place to be set
    /// down regardless of whether it's currently wrapping anything.</summary>
    public bool IsTowelKind => CanWrap;

    /// <summary>Whether this towel/cloth/rag currently has an ingredient
    /// wrapped inside - lets other Interactables (the cutting board, a bowl)
    /// tell "set this down" apart from their normal reaction to this tool.</summary>
    public bool IsWrapping => wrapped != null;

    private const float WrappedScaleBulge = 1.35f;

    private IngredientItem wrapped;
    private Collider wrappedCollider;
    private Renderer wrappedRenderer;

    private const float LoadedSpoonScaleBulge = 1.15f;
    private string loadedSeasoning;

    /// <summary>The scene's measuring spoon, registered by itself - a seasoning
    /// bottle "used" on something summons it into the hand for one scoop
    /// without needing a hand-wired reference on every bottle.</summary>
    public static ToolItem MeasuringSpoon { get; private set; }

    protected override void Awake()
    {
        base.Awake();
        if (kind == ToolKind.MeasuringSpoon) MeasuringSpoon = this;
    }

    void OnDestroy()
    {
        if (MeasuringSpoon == this) MeasuringSpoon = null;
    }

    /// <summary>Whether this measuring spoon currently holds one scooped dose,
    /// waiting to be poured into a bowl.</summary>
    public bool IsSpoonLoaded => loadedSeasoning != null;
    public string LoadedSeasoning => loadedSeasoning;

    /// <summary>Scoops one dose of the given seasoning onto this (empty)
    /// measuring spoon - called by SeasoningBottle.OnClickedWhileHandFull when
    /// this spoon, held in hand, clicks a bottle resting anywhere in the scene.</summary>
    public void LoadSeasoning(string seasoningName)
    {
        if (IsSpoonLoaded && loadedSeasoning == seasoningName) return;
        // A spoon still holding a different dose is emptied first (tipped back)
        // rather than mixing two seasonings in one spoonful.
        loadedSeasoning = seasoningName;
        transform.localScale = BaseLocalScale * LoadedSpoonScaleBulge;
    }

    /// <summary>Empties the spoon after its one loaded dose has been poured into
    /// a bowl - ready to scoop again.</summary>
    public void ConsumeSeasoning()
    {
        loadedSeasoning = null;
        transform.localScale = BaseLocalScale;
    }

    /// <summary>Wiping the knife with a held towel resets its cross-contamination
    /// state, the same relief the cutting board already gets from a towel wipe -
    /// without this, the only way to clear a dirtied knife was carrying it all
    /// the way to the sink.</summary>
    protected override void OnClickedWhileHandFull(Carryable held)
    {
        if (kind == ToolKind.Knife && held is ToolItem towel && towel.IsTowelKind)
        {
            GetComponent<HygieneTracker>()?.Wash();
            ProcessStageManager.Instance?.MarkWiped();
        }
    }

    /// <summary>Picking up a cloth/towel while an ingredient sits on the cutting
    /// board scoops that ingredient up wrapped inside it - the real exam move of
    /// carrying something in a towel instead of bare hands. Tucked away (hidden,
    /// uninteractable) as a child until the towel is set back down somewhere.</summary>
    protected override bool OnClickedWhileHandEmpty()
    {
        if (!CanWrap) return false;

        CuttingBoardController board = CuttingBoardController.Instance;
        IngredientItem ingredient = board != null ? board.Current as IngredientItem : null;
        if (ingredient == null || (object)ingredient.CurrentContainer != board) return false;

        board.Release(ingredient);
        ingredient.CurrentContainer = null;

        wrapped = ingredient;
        wrappedCollider = ingredient.GetComponent<Collider>();
        wrappedRenderer = ingredient.GetComponent<Renderer>();
        if (wrappedCollider != null) wrappedCollider.enabled = false;
        if (wrappedRenderer != null) wrappedRenderer.enabled = false;

        ingredient.transform.SetParent(transform, false);
        ingredient.transform.localPosition = Vector3.zero;

        HandCarry.Instance.PickUp(this);

        // PickUp() just reset localScale to BaseLocalScale - bulge it out
        // afterward so a wrapped towel visibly looks like it's carrying
        // something instead of being indistinguishable from an empty one.
        transform.localScale = BaseLocalScale * WrappedScaleBulge;
        return true;
    }

    /// <summary>Setting the towel down anywhere unwraps whatever it was carrying,
    /// leaving the ingredient at the towel's own landing spot with its collider
    /// and renderer restored.</summary>
    public override void OnPlaced()
    {
        base.OnPlaced();

        // Set down mid-chop: drop the stance so neither the knife nor the hand
        // stays turned/lifted.
        if (chopMotionRoutine != null)
        {
            StopCoroutine(chopMotionRoutine);
            chopMotionRoutine = null;
            chopBlend = 0f;
            SetTempHoldRotation(Quaternion.identity);
            HandController.Instance?.SetChopPose(0f, Vector3.zero);
        }

        if (wrapped == null) return;

        IngredientItem ingredient = wrapped;
        wrapped = null;

        ingredient.transform.SetParent(null, true);

        // Land just clear of the towel's own collider footprint (not just its
        // transform - the two can differ, e.g. an off-pivot mesh) so the two
        // don't overlap: a fixed small nudge isn't reliably outside a collider
        // whose actual bounds are bigger than its transform suggests. Placing
        // past the box's own extent on X guarantees no overlap on any axis.
        Collider towelCollider = GetComponent<Collider>();
        Bounds towelBounds = towelCollider != null
            ? towelCollider.bounds
            : new Bounds(transform.position, Vector3.zero);
        ingredient.transform.position = new Vector3(
            towelBounds.center.x + towelBounds.extents.x + 0.15f,
            towelBounds.center.y,
            towelBounds.center.z);

        if (wrappedCollider != null) wrappedCollider.enabled = true;
        if (wrappedRenderer != null) wrappedRenderer.enabled = true;
        wrappedCollider = null;
        wrappedRenderer = null;
    }

    [Header("Knife chop stance")]
    /// <summary>Flip the upright chop pose end-for-end if the blade (instead of
    /// the handle) ends up at 12 o'clock for this knife model.</summary>
    [SerializeField] private bool flipChopUpright;
    /// <summary>How high (world units) the knife lifts before each stroke.</summary>
    [SerializeField] private float chopLift = 0.25f;

    private Coroutine chopMotionRoutine;
    private Quaternion uprightChopRotation = Quaternion.identity;
    private float chopBlend;

    /// <summary>One up-and-down chop stroke - called by IngredientItem.CutRoutine
    /// on each chop pulse. The knife first stands upright (handle at 12 o'clock,
    /// blade down on the board) with the right hand turned to grip it, then
    /// lifts and comes straight down. The stroke moves the HAND (the knife
    /// rides the hand every frame via HandCarry), so hand and knife never
    /// separate; the upright turn is Carryable's tempHoldRotation, layered on
    /// the knife's resting pose since HandCarry.LateUpdate would overwrite a
    /// direct transform change the very next frame.</summary>
    public void PlayChopMotion()
    {
        if (kind != ToolKind.Knife || !IsHeld) return;
        if (chopMotionRoutine != null) StopCoroutine(chopMotionRoutine);
        else uprightChopRotation = ComputeUprightRotation();
        chopMotionRoutine = StartCoroutine(ChopMotionRoutine());
    }

    /// <summary>Turns the knife's long axis (its mesh's longest bounds axis)
    /// straight up on screen, keeping whichever end already points more upward
    /// on top - the resting knife lies with its handle toward the top, so that
    /// end stays up. Measured from the model itself, so a swapped knife model
    /// doesn't need re-calibrating (the old fixed -90 degree turn was tuned for
    /// a previous knife and chopped upside down with the cleaver).</summary>
    private Quaternion ComputeUprightRotation()
    {
        Renderer rend = GetComponent<Renderer>();
        if (rend == null) return Quaternion.identity;

        Vector3 size = rend.localBounds.size;
        Vector3 longLocal = size.x >= size.y && size.x >= size.z ? Vector3.right
                          : size.y >= size.z ? Vector3.up : Vector3.forward;

        Vector2 dir = BaseRotation * longLocal;
        if (dir.sqrMagnitude < 1e-6f) return Quaternion.identity;
        if (dir.y < 0f) dir = -dir;
        if (flipChopUpright) dir = -dir;

        return Quaternion.AngleAxis(Vector2.SignedAngle(dir, Vector2.up), Vector3.forward);
    }

    private IEnumerator ChopMotionRoutine()
    {
        yield return BlendChopPose(1f, 0.06f);
        yield return ChopStroke();

        // Grace window before easing back down to the normal carry pose - a
        // new pulse arriving before this elapses cancels it (PlayChopMotion
        // always stops the running coroutine first), so the knife stays
        // upright for an entire multi-piece cut instead of flopping back to
        // its lying pose between every single stroke.
        yield return new WaitForSeconds(0.35f);
        yield return BlendChopPose(0f, 0.15f);
        chopMotionRoutine = null;
    }

    /// <summary>Lift, then a quick straight-down "통" onto the board with a
    /// tiny dip past it, then settle.</summary>
    private IEnumerator ChopStroke()
    {
        yield return StrokeTo(0f, chopLift, 0.07f);
        yield return StrokeTo(chopLift, -0.03f, 0.04f);
        yield return StrokeTo(-0.03f, 0f, 0.05f);
    }

    private IEnumerator StrokeTo(float from, float to, float duration)
    {
        for (float t = 0f; t < duration; t += Time.deltaTime)
        {
            ApplyChopPose(Mathf.Lerp(from, to, t / duration));
            yield return null;
        }
        ApplyChopPose(to);
    }

    private IEnumerator BlendChopPose(float target, float duration)
    {
        float start = chopBlend;
        for (float t = 0f; t < duration; t += Time.deltaTime)
        {
            chopBlend = Mathf.Lerp(start, target, t / duration);
            ApplyChopPose(0f);
            yield return null;
        }
        chopBlend = target;
        ApplyChopPose(0f);
    }

    private void ApplyChopPose(float lift)
    {
        SetTempHoldRotation(Quaternion.Slerp(Quaternion.identity, uprightChopRotation, chopBlend));
        HandController.Instance?.SetChopPose(chopBlend, Vector3.up * lift);
    }
}

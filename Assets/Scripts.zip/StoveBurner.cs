using UnityEngine;

public class StoveBurner : Interactable, ISlotContainer
{
    public enum FlameLevel { Weak, Medium, Strong }

    [SerializeField] private GameObject flameWeak;
    [SerializeField] private GameObject flameMedium;
    [SerializeField] private GameObject flameStrong;

    public bool IsOn { get; private set; }
    public FlameLevel Level { get; private set; } = FlameLevel.Medium;

    /// <summary>The pot/pan/wok currently sitting on this burner, if any - a
    /// burner only ever holds one vessel at a time.</summary>
    public MovableBowl CurrentVessel { get; private set; }

    public override bool CanAcceptDrop(Carryable item) => item is MovableBowl && CurrentVessel == null;

    protected override void Activate()
    {
        HandCarry hand = HandCarry.Instance;
        if (hand?.Current is MovableBowl vessel && CurrentVessel == null)
        {
            if (hand.PlaceAtAnchor(transform))
            {
                CurrentVessel = vessel;
                vessel.CurrentContainer = this;
                vessel.SetBurner(this);
            }
            return;
        }

        // No vessel to place (hand empty or holding something else) - falls back
        // to the burner's own bare on/off toggle, same as clicking it always did
        // before placement existed (the physical knob is the normal way to do
        // this, but nothing stops the burner itself from still responding).
        if (hand?.Current == null)
        {
            IsOn = !IsOn;
            UpdateVisual();
        }
    }

    public void Release(Carryable item)
    {
        if ((object)CurrentVessel == item)
        {
            CurrentVessel.SetBurner(null);
            CurrentVessel = null;
        }
    }

    /// <summary>Sets on/off directly rather than toggling - for a control (the
    /// physical knob) that always knows the absolute state it wants, unlike a
    /// click which only ever flips whatever the current state happens to be.</summary>
    public void SetOn(bool on)
    {
        IsOn = on;
        UpdateVisual();
    }

    /// <summary>Switches how high the flame is set - independent of on/off, same
    /// as a real stove knob's position stays put whether the burner is lit or
    /// not. Public so the physical lever/knob prop (added separately) can call
    /// this directly instead of going through Activate()'s click-to-toggle.</summary>
    public void SetLevel(FlameLevel level)
    {
        Level = level;
        if (IsOn) UpdateVisual();
    }

    private void UpdateVisual()
    {
        SetFlameActive(flameWeak, IsOn && Level == FlameLevel.Weak);
        SetFlameActive(flameMedium, IsOn && Level == FlameLevel.Medium);
        SetFlameActive(flameStrong, IsOn && Level == FlameLevel.Strong);
    }

    private void SetFlameActive(GameObject flame, bool active)
    {
        if (flame == null) return;
        flame.SetActive(active);

        // Some VFX prefabs don't have Play On Awake set (they're meant to be
        // triggered programmatically) - SetActive alone leaves them sitting
        // idle with zero particles instead of actually starting the effect.
        if (active)
        {
            foreach (var ps in flame.GetComponentsInChildren<ParticleSystem>(true)) ps.Play();
        }
    }
}

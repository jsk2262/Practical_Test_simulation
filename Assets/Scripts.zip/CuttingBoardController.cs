using System.Collections;
using UnityEngine;

[RequireComponent(typeof(HygieneTracker))]
public class CuttingBoardController : PlaceSlot
{
    public static CuttingBoardController Instance { get; private set; }

    /// <summary>Half-extents (real-world-like units) an ingredient may land within,
    /// measured from the board's center.</summary>
    [SerializeField] private Vector2 placementExtents = new Vector2(1.1f, 0.75f);

    public HygieneTracker Hygiene { get; private set; }

    private Transform ingredientRoot;

    private Transform IngredientRoot
    {
        get
        {
            if (ingredientRoot == null)
            {
                // Runtime-only field, resets to null on every reload even though the
                // child itself (if this board already held something before) is
                // still there - reuse it instead of creating a duplicate.
                Transform existing = transform.Find("IngredientRoot");
                if (existing != null)
                {
                    ingredientRoot = existing;
                }
                else
                {
                    var go = new GameObject("IngredientRoot");
                    ingredientRoot = go.transform;
                    ingredientRoot.SetParent(transform, false);

                    // Cancel the board's own scale/rotation so an ingredient placed
                    // here keeps its natural size and stays screen-aligned instead
                    // of inheriting the board's own stretch/tilt.
                    Vector3 s = transform.lossyScale;
                    ingredientRoot.localScale = new Vector3(
                        Mathf.Approximately(s.x, 0f) ? 1f : 1f / s.x,
                        Mathf.Approximately(s.y, 0f) ? 1f : 1f / s.y,
                        Mathf.Approximately(s.z, 0f) ? 1f : 1f / s.z);
                    ingredientRoot.rotation = Quaternion.identity;
                }
            }

            return ingredientRoot;
        }
    }

    protected override void Awake()
    {
        base.Awake();
        Instance = this;
        Hygiene = GetComponent<HygieneTracker>();
    }

    protected override void Activate()
    {
        HandCarry hand = HandCarry.Instance;
        if (hand?.Current is ToolItem tool && (tool.Kind == ToolKind.Rag || tool.Kind == ToolKind.Cloth || tool.Kind == ToolKind.PaperTowel))
        {
            // A towel currently wrapping an ingredient is being set down, not
            // used to wipe - without this check there was no way to ever let
            // go of a wrapped towel here, since this branch always intercepted
            // the click first (the knife's own placement branch below, and
            // ResetToBaseScale from PlaceAtAnchor undoing the wrap bulge, only
            // run in the else case).
            if (tool.IsWrapping)
            {
                if (hand.PlaceAtAnchor(Anchor)) tool.CurrentContainer = this;
                return;
            }

            Hygiene.Wash();
            ProcessStageManager.Instance?.MarkWiped();
            return;
        }

        // The knife's resting spot on the board is tracked independently of
        // PlaceSlot's own Current (reserved for the ingredient being cut) -
        // going through the normal Accepts()/Current-gated path here would
        // either reject the knife outright (accepts is IngredientOnly) or,
        // if allowed, let it occupy the one slot and block every ingredient
        // drop until it's picked back up.
        if (hand?.Current is ToolItem knife && knife.Kind == ToolKind.Knife)
        {
            if (hand.PlaceAtAnchor(Anchor)) knife.CurrentContainer = this;
            return;
        }

        // Ingredients land wherever they were actually dropped (clamped to the
        // board's surface) rather than snapping to Anchor's one fixed spot -
        // PlaceSlot's default Activate() always uses Anchor, which is also
        // where the knife rests (off toward one corner), so every ingredient
        // used to end up there regardless of where the player aimed.
        if (hand?.Current is IngredientItem ingredient && Current == null && Accepts(ingredient))
        {
            PlaceIngredientFree(ingredient);
            return;
        }

        base.Activate();
    }

    private void PlaceIngredientFree(IngredientItem item)
    {
        Transform root = IngredientRoot;

        // A plain click carries no aim - the item's transform is just wherever
        // the hand happens to be resting (a fixed spot near this board), so
        // using it as "desired" always lands on roughly the same point. Only a
        // real drag (HandCarry.DropIsFromDrag) has a position worth honoring;
        // a click instead lands centered on the board.
        Vector3 desired = HandCarry.Instance != null && HandCarry.Instance.DropIsFromDrag
            ? root.InverseTransformPoint(item.transform.position)
            : Vector3.zero;

        Vector3 clamped = new Vector3(
            Mathf.Clamp(desired.x, -placementExtents.x, placementExtents.x),
            Mathf.Clamp(desired.y, -placementExtents.y, placementExtents.y),
            -0.05f);

        if (HandCarry.Instance.PlaceAtFreeLocalPosition(root, clamped))
        {
            item.CurrentContainer = this;
            Current = item;
        }
    }

    public override bool CanAcceptDrop(Carryable item)
    {
        if (item is ToolItem tool && (tool.Kind == ToolKind.Rag || tool.Kind == ToolKind.Cloth || tool.Kind == ToolKind.PaperTowel))
            return true;

        if (item is ToolItem knife && knife.Kind == ToolKind.Knife)
            return true;

        return base.CanAcceptDrop(item);
    }

    private bool isFlipping;

    /// <summary>The side NOT currently facing up - starts clean (unused) the
    /// first time the board is ever flipped, and from then on keeps whatever
    /// mess it was left with, independently of the active side.</summary>
    private IngredientCategory otherSideLastCategory = IngredientCategory.None;

    /// <summary>Flips the board onto its other side - a quicker alternative to
    /// carrying it to the sink when you're mid-something and need a clean
    /// surface right now. Unlike actually washing it, this doesn't erase the
    /// mess: the side just turned away keeps whatever category dirtied it, and
    /// flipping back to it later still carries that same violation risk until
    /// it's properly washed.</summary>
    public void Flip()
    {
        if (isFlipping) return;
        StartCoroutine(FlipRoutine());
    }

    private IEnumerator FlipRoutine()
    {
        isFlipping = true;

        // Anchor sits off-center now (the knife's rest spot, moved out to the
        // board's corner) - unlike a tool sitting exactly at the board's own
        // pivot, an off-center child DOES drift in world space when its parent
        // rotates 180 degrees (the local offset that used to read as "toward
        // the camera" now reads as "toward the player" or vice versa). Pinning
        // Anchor's world position back afterward keeps the knife's rest spot a
        // fixed physical place beside the board, the way flipping a real board
        // never relocates whatever's sitting next to it.
        Vector3 anchorWorldPosBeforeFlip = Anchor.position;

        // Tips end-over-end around the board's own local X axis - the way a
        // flat board actually flips to show its other face, rather than
        // spinning in place around the axis facing the camera.
        Quaternion start = transform.rotation;
        Quaternion end = start * Quaternion.Euler(180f, 0f, 0f);
        const float duration = 0.4f;
        float t = 0f;

        while (t < duration)
        {
            t += Time.deltaTime;
            transform.rotation = Quaternion.Slerp(start, end, t / duration);
            yield return null;
        }

        transform.rotation = end;
        if (Anchor != transform) Anchor.position = anchorWorldPosBeforeFlip;

        // Swap which side's history is active - the side just turned away
        // keeps its own mess untouched, and whatever the newly-up side was
        // last left with (clean, the first time) comes back as the active
        // state.
        IngredientCategory justLeft = Hygiene.LastCategory;
        Hygiene.SetState(otherSideLastCategory);
        otherSideLastCategory = justLeft;

        // IngredientRoot's own rotation was pinned to world-identity once, at
        // creation time, to keep contents screen-aligned - the board rotating
        // out from under it here would otherwise leave that pin stale (it'd
        // now be rotated right along with the board), misaligning whatever
        // gets placed next.
        if (ingredientRoot != null) ingredientRoot.rotation = Quaternion.identity;

        ReseatToolsAfterFlip();

        isFlipping = false;
    }

    /// <summary>A tool resting on the board tumbles right along with its
    /// 180-degree flip: its facing changes, and since the board's own
    /// collider isn't symmetric front-to-back around its pivot, the flip can
    /// leave the board's new front face closer to the camera than the
    /// now-backwards-facing tool - silently burying it behind the board and
    /// making it unclickable. Re-facing the tool and pulling it in front of
    /// the board's own (post-flip) surface fixes both.
    /// Searches the whole hierarchy (not just direct children) since Anchor is
    /// itself a child object the tool rests under, one level deeper than the
    /// board's own transform - a shallow direct-children scan missed it
    /// entirely, leaving a flipped knife stuck on the board's back face.</summary>
    private void ReseatToolsAfterFlip()
    {
        Collider boardCollider = GetComponent<Collider>();
        float safeZ = boardCollider != null ? boardCollider.bounds.min.z - 0.05f : transform.position.z - 0.2f;

        foreach (ToolItem tool in GetComponentsInChildren<ToolItem>(true))
        {
            if (ingredientRoot != null && tool.transform.IsChildOf(ingredientRoot)) continue;

            // A tool resting at a dedicated anchor (not directly on the
            // board's own transform) belongs at that anchor's exact position -
            // any local drift it picked up (from earlier pickup/place cycles)
            // would otherwise ride along through the flip's rotation math and
            // land somewhere else on the board entirely (reproduced: the knife
            // sliding to the board's bottom edge after a flip). Snapping home
            // to local zero is safe here since PlaceAtAnchor always parks a
            // tool there in the first place.
            if (tool.transform.parent != transform)
            {
                tool.transform.localPosition = Vector3.zero;
                tool.transform.rotation = tool.BaseRotation;
                continue;
            }

            // Restore the tool's own correct resting rotation (the knife's isn't
            // identity - see Carryable.BaseRotation) rather than assuming identity.
            tool.transform.rotation = tool.BaseRotation;
            Vector3 wp = tool.transform.position;
            wp.z = safeZ;
            tool.transform.position = wp;
        }
    }
}

using UnityEngine;

/// <summary>
/// The physical stove dial - clicked to step through its settings, one click
/// at a time: off -> strong -> medium -> weak -> off, same as a real gas valve
/// that opens fully first and gets dialed down click by click rather than
/// needing to be turned to an exact angle.
/// </summary>
public class StoveKnob : MonoBehaviour, IClickable
{
    [SerializeField] private StoveBurner burner;

    private const float OffAngle = 0f;
    private const float WeakAngle = 45f;
    private const float MediumAngle = 90f;
    private const float StrongAngle = 135f;

    private float angle;
    private Quaternion baseRotation;
    private bool baseRotationCaptured;

    void Awake()
    {
        CaptureBaseRotation();
    }

    /// <summary>The mesh was hand-placed with its own rest tilt (an extracted
    /// FBX part, not authored at a clean identity rotation) - stepping the
    /// dial must spin it from THAT orientation, not reset it to a clean
    /// (0,0,0) on the first click.</summary>
    private void CaptureBaseRotation()
    {
        if (baseRotationCaptured) return;
        baseRotation = transform.rotation;
        baseRotationCaptured = true;
    }

    public void OnClicked()
    {
        CaptureBaseRotation();
        angle = NextAngle(angle);
        Apply();
    }

    private static float NextAngle(float current)
    {
        if (current <= OffAngle + 0.01f) return StrongAngle;
        if (current >= StrongAngle - 0.01f) return MediumAngle;
        if (current >= MediumAngle - 0.01f) return WeakAngle;
        return OffAngle;
    }

    private void Apply()
    {
        // Spin around the world Z axis (the camera's own view axis, since this
        // is a face-on 2.5D scene) on top of the mesh's own rest orientation,
        // rather than replacing the rotation outright - see CaptureBaseRotation.
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward) * baseRotation;

        if (burner == null) return;

        if (angle <= OffAngle + 0.01f)
        {
            burner.SetOn(false);
            return;
        }

        StoveBurner.FlameLevel level =
            angle <= WeakAngle + 0.01f ? StoveBurner.FlameLevel.Weak :
            angle <= MediumAngle + 0.01f ? StoveBurner.FlameLevel.Medium :
            StoveBurner.FlameLevel.Strong;

        burner.SetLevel(level);
        burner.SetOn(true);
    }
}

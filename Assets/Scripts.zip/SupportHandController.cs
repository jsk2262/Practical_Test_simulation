using System.Collections;
using UnityEngine;

/// <summary>
/// The off-hand (left) - normally hidden, appears near an ingredient to hold it
/// steady during a two-handed action like knife cutting, or beside the primary
/// hand to wash together, while the primary (right, cursor-following) hand does
/// the actual work. Purely a visual prop: it isn't clickable and doesn't
/// participate in HandCarry.
/// </summary>
public class SupportHandController : MonoBehaviour
{
    public static SupportHandController Instance { get; private set; }

    [SerializeField] private Vector3 holdOffset = new Vector3(-0.55f, -0.1f, -0.05f);
    [SerializeField] private Vector3 washBesideOffset = new Vector3(-0.55f, 0f, -0.05f);
    [SerializeField] private float gripCurl = 0.5f;
    /// <summary>Where this hand sits relative to the (hidden) primary hand
    /// while gripping a pan's handle - zero puts it exactly where the right
    /// hand would be, i.e. its palm on the usual holding spot.</summary>
    [SerializeField] private Vector3 handleGripOffset = Vector3.zero;
    [SerializeField] private float handleGripCurl = 0.8f;
    [Header("Cutting stance")]
    /// <summary>Where the middle knuckle sits relative to the ingredient.</summary>
    [SerializeField] private Vector3 cutKnuckleOffset = new Vector3(-0.35f, 0f, -0.05f);
    [SerializeField] private bool cutPalmUp;

    private Quaternion restRotation;

    private GleechiHandPoser poser;
    private GameObject visual;
    private Coroutine autoHideRoutine;
    private Transform followTarget;
    private Vector3 followOffset;

    void Awake()
    {
        Instance = this;
        poser = GetComponentInChildren<GleechiHandPoser>(true);
        restRotation = transform.rotation;

        // The root itself must stay active for this Awake() (and thus
        // Instance) to run at all - only the visual child toggles, so
        // ShowNear()/Hide() never depend on this object already being active.
        if (poser != null) visual = poser.gameObject;
        visual?.SetActive(false);
    }

    void LateUpdate()
    {
        // The primary hand keeps cosmetically traveling toward wherever was
        // just clicked (HandController.GoTo, kicked off right after the click
        // that started this wash) - a one-time position snapshot taken at the
        // start of the gesture would freeze this hand behind while the primary
        // hand walks away, so it re-anchors every frame instead.
        if (followTarget != null)
        {
            transform.position = followTarget.position + followOffset;
        }
    }

    /// <summary>Takes over holding a pan by its handle (see Carryable's
    /// holdByHandle) - follows the primary hand every frame, curled into a
    /// grip, until Hide().</summary>
    public void ShowGripping(Transform primaryHand)
    {
        CancelAutoHide();
        followTarget = primaryHand;
        followOffset = handleGripOffset;
        transform.rotation = restRotation;
        transform.position = primaryHand.position + followOffset;
        visual?.SetActive(true);
        poser?.SetCurl(handleGripCurl);
    }

    /// <summary>Shows the support hand holding steady just beside the given
    /// world position (e.g. an ingredient on the cutting board). Stays until
    /// Hide() is called explicitly.</summary>
    public void ShowNear(Vector3 worldPos)
    {
        CancelAutoHide();
        followTarget = null;
        transform.rotation = restRotation;
        transform.position = worldPos + holdOffset;
        visual?.SetActive(true);
        poser?.SetCurl(gripCurl);

        // Cutting stance: flat on the board beside the ingredient, fingers
        // pointing at 3 o'clock (toward the ingredient/knife), back of the hand
        // up - for a left hand that means the thumb side faces 6 o'clock.
        // cutPalmUp flips it over (thumb side 12 o'clock).
        if (poser != null && poser.TryGetAimRotation(Vector3.right, cutPalmUp ? Vector3.up : Vector3.down, out Quaternion aim))
        {
            transform.rotation = aim * transform.rotation;
            // Knuckles just left of the ingredient, so the fingers rest on it.
            transform.position += (worldPos + cutKnuckleOffset) - poser.KnucklePosition;
        }
    }

    /// <summary>Brings the off-hand in right beside the primary hand and rubs
    /// it through the same wash motion, so washing hands/rinsing an ingredient
    /// reads as two hands scrubbing together instead of one hand alone - then
    /// hides itself again once the gesture finishes. Keeps tracking
    /// primaryHand's transform every frame (see LateUpdate) rather than just
    /// its position at this instant, since the primary hand is usually still
    /// mid-travel toward this same click when the gesture starts.</summary>
    public void ShowWashingBeside(Transform primaryHand, float duration)
    {
        CancelAutoHide();
        followTarget = primaryHand;
        followOffset = washBesideOffset;
        transform.rotation = restRotation;
        transform.position = primaryHand.position + followOffset;
        visual?.SetActive(true);
        poser?.PlayWashGesture(duration);
        autoHideRoutine = StartCoroutine(HideAfter(duration));
    }

    private IEnumerator HideAfter(float duration)
    {
        yield return new WaitForSeconds(duration);
        autoHideRoutine = null;
        Hide();
    }

    private void CancelAutoHide()
    {
        if (autoHideRoutine == null) return;
        StopCoroutine(autoHideRoutine);
        autoHideRoutine = null;
    }

    public void Hide()
    {
        CancelAutoHide();
        followTarget = null;
        visual?.SetActive(false);
    }
}

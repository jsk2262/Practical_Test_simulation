using UnityEngine;

public enum CookProcess { Grill, Blanch, Boil, StirFry, DeepFry }

/// <summary>
/// Unified fire-based cooking for an ingredient sitting in a pot/wok on a burner.
/// Grill/Blanch/Boil/DeepFry progress passively over time while the burner is on.
/// StirFry instead needs the wok actively shaken (see WokDragHandler) - fast
/// dragging builds cookProgress, leaving it still builds burnProgress instead.
/// </summary>
public class CookableItem : MonoBehaviour
{
    public enum Stage { Raw, InProgress, Done, Burnt }

    [SerializeField] private CookProcess process = CookProcess.Grill;
    [SerializeField] private StoveBurner burner;
    [SerializeField] private WokDragHandler wok;
    [SerializeField] private float timeToCooked = 6f;
    [SerializeField] private float timeToBurnt = 14f;
    [SerializeField] private float shakeThreshold = 300f;
    [SerializeField] private int requiredFryPasses = 2;

    private static readonly Color CookedColor = new Color(0.45f, 0.28f, 0.15f);
    private static readonly Color BurntColor = new Color(0.08f, 0.08f, 0.08f);
    private static readonly Color BlanchedColor = new Color(0.35f, 0.75f, 0.3f);

    private float cookProgress;
    private float burnProgress;
    private Renderer rend;
    private Color rawColor;

    public Stage CurrentStage { get; private set; } = Stage.Raw;
    public bool IsColdShocked { get; private set; }
    public int FryPasses { get; private set; }

    /// <summary>Which burner (if any) this item's cooking progresses under -
    /// set dynamically by whatever pot/pan/wok it's currently sitting in, since
    /// that vessel can be picked up and moved between burners rather than being
    /// wired to one fixed burner at design time.</summary>
    public void SetBurner(StoveBurner newBurner)
    {
        burner = newBurner;
    }

    public void SetWok(WokDragHandler newWok)
    {
        wok = newWok;
    }

    void Start()
    {
        rend = GetComponent<Renderer>();
        rawColor = rend.sharedMaterial.color;
        rend.material = new Material(rend.sharedMaterial);
    }

    void Update()
    {
        if (CurrentStage == Stage.Done || CurrentStage == Stage.Burnt) return;
        if (burner == null || !burner.IsOn) return;

        if (process == CookProcess.StirFry)
        {
            float shakeSpeed = wok != null ? wok.ShakeSpeed : 0f;
            if (shakeSpeed >= shakeThreshold) cookProgress += Time.deltaTime;
            else burnProgress += Time.deltaTime;
        }
        else
        {
            cookProgress += Time.deltaTime;
        }

        CurrentStage = Stage.InProgress;
        UpdateVisual();

        if (burnProgress >= timeToBurnt)
        {
            CurrentStage = Stage.Burnt;
            rend.material.color = BurntColor;
            return;
        }

        if (cookProgress >= timeToCooked)
        {
            FryPasses++;

            if (process == CookProcess.DeepFry && FryPasses < requiredFryPasses)
            {
                cookProgress = 0f; // needs another pass in the oil
                return;
            }

            CurrentStage = Stage.Done;
        }
    }

    private void UpdateVisual()
    {
        Color target = (process == CookProcess.Blanch || process == CookProcess.Boil) ? BlanchedColor : CookedColor;
        float t = Mathf.Clamp01(cookProgress / timeToCooked);
        rend.material.color = Color.Lerp(rawColor, target, t);
    }

    /// <summary>Shocks a blanched/boiled item in cold water, locking in its color.</summary>
    public void ColdShock()
    {
        if (process != CookProcess.Blanch && process != CookProcess.Boil) return;
        if (CurrentStage != Stage.Done) return;

        IsColdShocked = true;
        rend.material.color = Color.Lerp(rend.material.color, Color.white, 0.15f);
    }
}

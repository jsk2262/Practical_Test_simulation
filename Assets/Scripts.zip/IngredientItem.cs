using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IngredientItem : Carryable
{
    public enum State { Raw, Washed, Cut }
    public enum SoakState { NotNeeded, Dry, Soaking, Soaked }
    public enum CutMethod { None, Julienne, Slice, Dice, StairCut, FlowerCut, DiagonalCut, Tear, Other }

    [SerializeField] private string ingredientName = "재료";
    [SerializeField] private IngredientCategory category = IngredientCategory.None;
    [SerializeField] private bool isSoakable = false;
    [SerializeField] private float soakDuration = 5f;

    /// <summary>Meat needs to be blotted with a paper towel after cutting to draw
    /// off excess blood, like in the real exam - purely visual/practice, not
    /// hygiene-scored (HygieneLog is about cross-contamination, not this).</summary>
    [SerializeField] private bool needsBloodDrain = false;

    /// <summary>Optional pre-modeled cut result (e.g. the onion's real half-mesh
    /// with an actual cross-section texture) - when set, cutting swaps this
    /// ingredient's own mesh/material to these instead of spawning the generic
    /// scaled-quad "Piece_i" placeholders every other ingredient still uses.
    /// Left null, behavior is unchanged.</summary>
    [SerializeField] private Mesh cutResultMesh;
    [SerializeField] private Material cutResultMaterial;

    public IngredientCategory Category => category;
    public string IngredientName => ingredientName;

    private Renderer rend;
    private Mesh sharedMesh;
    private float soakTimer;

    public State CurrentState { get; private set; } = State.Raw;
    public CutMethod AppliedCut { get; private set; } = CutMethod.None;
    public CutSpec AppliedSpec { get; private set; }
    public SoakState CurrentSoakState { get; private set; } = SoakState.NotNeeded;
    public bool BloodDrained { get; private set; }

    /// <summary>True only once this piece actually needs (and hasn't yet had) a
    /// paper towel blot - before cutting there's nothing to blot yet.</summary>
    private bool NeedsBloodDrain => needsBloodDrain && CurrentState == State.Cut && !BloodDrained;

    private readonly Dictionary<string, int> appliedSeasonings = new Dictionary<string, int>();
    public IReadOnlyDictionary<string, int> AppliedSeasonings => appliedSeasonings;

    protected override void Awake()
    {
        base.Awake();
        rend = GetComponent<Renderer>();
        rend.material = new Material(rend.sharedMaterial);
        sharedMesh = GetComponent<MeshFilter>().sharedMesh;

        if (isSoakable) CurrentSoakState = SoakState.Dry;
    }

    void Update()
    {
        if (CurrentSoakState != SoakState.Soaking) return;

        soakTimer += Time.deltaTime;
        rend.material.color = Color.Lerp(rend.material.color, new Color(0.55f, 0.4f, 0.35f), Time.deltaTime * 0.3f);

        if (soakTimer >= soakDuration)
        {
            CurrentSoakState = SoakState.Soaked;
        }
    }

    public bool NeedsSoaking => isSoakable && CurrentSoakState != SoakState.Soaked;

    public void StartSoaking()
    {
        if (!isSoakable || CurrentSoakState == SoakState.Soaking || CurrentSoakState == SoakState.Soaked) return;
        CurrentSoakState = SoakState.Soaking;
        soakTimer = 0f;
    }

    public void Wash()
    {
        if (CurrentState != State.Raw) return;

        CurrentState = State.Washed;
        StopCoroutine(nameof(WashMotion));
        StartCoroutine(nameof(WashMotion));
    }

    private IEnumerator WashMotion()
    {
        Vector3 baseS = BaseLocalScale;
        float duration = 0.35f;
        float t = 0f;

        while (t < duration)
        {
            t += Time.deltaTime;
            float decay = 1f - t / duration;
            float wobble = Mathf.Sin(t * Mathf.PI * 8f) * 0.1f * decay;
            transform.localScale = baseS * (1f + wobble);
            yield return null;
        }

        transform.localScale = baseS;
    }

    protected override bool OnClickedWhileHandEmpty()
    {
        // Soaked, tear-only ingredients (e.g. wood ear mushroom) skip the knife entirely.
        if (isSoakable && CurrentSoakState == SoakState.Soaked && CurrentState != State.Cut)
        {
            PerformCut(CutMethod.Tear);
            return true;
        }

        return false;
    }

    /// <summary>True only while this ingredient is actually sitting on the cutting
    /// board - cutting (like in the real exam) has to happen there, not wherever the
    /// knife happens to touch it (a plate, the raw-ingredient strip, etc).</summary>
    private bool IsOnCuttingBoard => CurrentContainer != null && (object)CurrentContainer == CuttingBoardController.Instance;

    public override bool CanAcceptDrop(Carryable item)
    {
        if (item is SeasoningBottle) return true;
        if (item is ToolItem spoon && spoon.Kind == ToolKind.MeasuringSpoon && spoon.IsSpoonLoaded) return true;
        if (item is ToolItem knife && knife.Kind == ToolKind.Knife && CurrentState != State.Cut && !NeedsSoaking && IsOnCuttingBoard) return true;
        if (item is ToolItem towel && towel.Kind == ToolKind.PaperTowel && NeedsBloodDrain) return true;
        return false;
    }

    private void AddSeasoning(string seasoningName)
    {
        appliedSeasonings.TryGetValue(seasoningName, out int count);
        appliedSeasonings[seasoningName] = count + 1;
        StopCoroutine(nameof(ChopPulse));
        StartCoroutine(nameof(ChopPulse));
    }

    /// <summary>Blots the cut pieces with a paper towel to draw off blood - the
    /// original ingredient's own renderer is already off post-cut, so this tints
    /// each spawned Piece_i instead (each gets its own material instance the
    /// first time .material is touched, so this doesn't bleed into siblings
    /// still sharing rend.sharedMaterial).</summary>
    private void DrainBlood()
    {
        BloodDrained = true;

        foreach (Transform child in transform)
        {
            Renderer pieceRend = child.GetComponent<Renderer>();
            if (pieceRend == null) continue;
            pieceRend.material.color = Color.Lerp(pieceRend.material.color, Color.white, 0.3f);
        }

        StopCoroutine(nameof(ChopPulse));
        StartCoroutine(nameof(ChopPulse));
    }

    protected override void OnClickedWhileHandFull(Carryable held)
    {
        // Using a bottle here measures one spoonful into the measuring spoon
        // first (bottle goes back to the shelf, spoon ends up in hand)...
        if (held is SeasoningBottle bottle)
        {
            bottle.TryScoopWithSpoon();
            return;
        }

        // ...and the loaded spoon is what actually adds the dose.
        if (held is ToolItem spoon && spoon.Kind == ToolKind.MeasuringSpoon && spoon.IsSpoonLoaded)
        {
            AddSeasoning(spoon.LoadedSeasoning);
            spoon.ConsumeSeasoning();
            return;
        }

        if (held is ToolItem towel && towel.Kind == ToolKind.PaperTowel && NeedsBloodDrain)
        {
            DrainBlood();
            return;
        }

        if (held is ToolItem tool && tool.Kind == ToolKind.Knife && CurrentState != State.Cut && !NeedsSoaking)
        {
            if (!IsOnCuttingBoard)
            {
                // Not a hygiene violation (doesn't touch HygieneLog's score) - just a
                // reminder that cutting has to happen on the board, like in the real exam.
                Debug.Log($"{ingredientName}: 도마 위에서만 손질할 수 있어요");
                return;
            }

            HygieneTracker knifeHygiene = tool.GetComponent<HygieneTracker>();
            HygieneTracker boardHygiene = CuttingBoardController.Instance?.Hygiene;

            bool knifeDirty = knifeHygiene != null && knifeHygiene.RegisterUse(category);
            bool boardDirty = boardHygiene != null && boardHygiene.RegisterUse(category);

            if (knifeDirty || boardDirty)
            {
                string what = knifeDirty && boardDirty ? "칼·도마" : knifeDirty ? "칼" : "도마";
                HygieneLog.Instance?.ReportViolation($"{ingredientName} 손질: {what} 세척 없이 교차 사용 (교차오염)");
            }

            CutMethodChooser.Instance.Show(transform.position + Vector3.up * 0.9f, PerformCut);
        }
    }

    private bool isCutting;

    /// <summary>Reference (standard-spec) thickness per method, in cm - the size our
    /// baseline piece visuals were tuned for. Chosen thickness scales visuals from here.</summary>
    public static float ReferenceThicknessCm(CutMethod method)
    {
        switch (method)
        {
            case CutMethod.Julienne: return 0.3f;
            case CutMethod.Dice: return 0.5f;
            case CutMethod.StairCut: return 1.0f;
            case CutMethod.FlowerCut: return 1.0f;
            case CutMethod.DiagonalCut: return 1.5f;
            case CutMethod.Tear: return 1.0f;
            default: return 0.4f; // Slice
        }
    }

    /// <summary>Builds a full width/length/thickness spec for a method given just the
    /// thickness the player chose - width and length follow each method's usual shape.</summary>
    public static CutSpec BuildSpec(CutMethod method, float thicknessCm)
    {
        switch (method)
        {
            case CutMethod.Julienne: return new CutSpec(thicknessCm, 6f, thicknessCm);
            case CutMethod.Dice: return new CutSpec(thicknessCm, thicknessCm, thicknessCm);
            default: return new CutSpec(thicknessCm * 4f, thicknessCm * 3f, thicknessCm);
        }
    }

    public void PerformCut(CutMethod method)
    {
        PerformCut(method, BuildSpec(method, ReferenceThicknessCm(method)));
    }

    public void PerformCut(CutMethod method, CutSpec spec)
    {
        if (CurrentState == State.Cut || isCutting) return;
        StartCoroutine(CutRoutine(method, spec));
    }

    private IEnumerator CutRoutine(CutMethod method, CutSpec spec)
    {
        isCutting = true;
        AppliedCut = method;
        AppliedSpec = spec;

        // The off-hand holds the piece steady near where it actually sits (not
        // just the ingredient's own root) for the whole cut, then lets go.
        SupportHandController.Instance?.ShowNear(transform.position);

        int pieceCount;
        float spreadRange;
        float sx, sy;

        switch (method)
        {
            case CutMethod.Julienne:
                pieceCount = 9; spreadRange = 0.3f; sx = 0.10f; sy = 0.85f;
                break;
            case CutMethod.Dice:
                pieceCount = 12; spreadRange = 0.35f; sx = 0.14f; sy = 0.5f;
                break;
            case CutMethod.StairCut:
                pieceCount = 5; spreadRange = 0.28f; sx = 0.30f; sy = 0.30f;
                break;
            case CutMethod.FlowerCut:
                pieceCount = 6; spreadRange = 0.25f; sx = 0.22f; sy = 0.22f;
                break;
            case CutMethod.DiagonalCut:
                pieceCount = 4; spreadRange = 0.3f; sx = 0.40f; sy = 0.55f;
                break;
            case CutMethod.Tear:
                pieceCount = 5; spreadRange = 0.3f; sx = 0.28f; sy = 0.22f;
                break;
            default: // Slice
                pieceCount = 4; spreadRange = 0.3f; sx = 0.35f; sy = 0.85f;
                break;
        }

        // scale the piece visual by how far the chosen thickness is from the reference
        float thicknessRatio = Mathf.Clamp(spec.thicknessCm / ReferenceThicknessCm(method), 0.4f, 2.5f);
        sx *= thicknessRatio;

        if (cutResultMesh != null)
        {
            // Same chop timing/feedback as the generic path, just without
            // spawning placeholder pieces - the swap below is the "piece".
            for (int i = 0; i < pieceCount; i++)
            {
                HandController.Instance?.PlayChopGesture();
                (HandCarry.Instance?.Current as ToolItem)?.PlayChopMotion();
                yield return StartCoroutine(ChopPulse());
                yield return new WaitForSeconds(0.16f);
            }

            GetComponent<MeshFilter>().sharedMesh = cutResultMesh;
            if (cutResultMaterial != null) rend.material = cutResultMaterial;

            CurrentState = State.Cut;
            isCutting = false;
            yield break;
        }

        for (int i = 0; i < pieceCount; i++)
        {
            // brief "chop impact" pulse, then one slice pops off - parented to this
            // ingredient (not the world) so it keeps traveling with it if carried later.
            HandController.Instance?.PlayChopGesture();
            (HandCarry.Instance?.Current as ToolItem)?.PlayChopMotion();
            yield return StartCoroutine(ChopPulse());

            GameObject piece = new GameObject($"Piece_{i}");
            piece.transform.SetParent(transform, false);
            piece.AddComponent<MeshFilter>().sharedMesh = sharedMesh;
            piece.AddComponent<MeshRenderer>().sharedMaterial = rend.sharedMaterial;
            piece.AddComponent<CutResultPiece>().Init(ingredientName, method, spec);

            float t = pieceCount <= 1 ? 0f : (float)i / (pieceCount - 1);
            float edgeX = Mathf.Lerp(-spreadRange, spreadRange, t);
            float ry = Random.Range(-spreadRange * 0.3f, spreadRange * 0.3f);
            piece.transform.localPosition = new Vector3(edgeX, -0.35f + ry, -0.02f - 0.001f * i);
            piece.transform.localScale = new Vector3(sx, sy, 1f);

            yield return new WaitForSeconds(0.16f);
        }

        CurrentState = State.Cut;
        rend.enabled = false;
        isCutting = false;

        SupportHandController.Instance?.Hide();

        ExpandColliderToCoverPieces();
    }

    /// <summary>The original collider was sized for the whole, uncut shape - once
    /// cutting scatters the visible Piece_i children out across spreadRange (which
    /// can exceed the original footprint, especially for thin ingredients), clicks
    /// aimed at a piece the player can actually see can land outside that stale
    /// collider and silently miss the ingredient entirely. Piece_i objects have no
    /// colliders of their own (they're purely visual), so this swaps in one box
    /// sized to cover all of them instead.</summary>
    private void ExpandColliderToCoverPieces()
    {
        Collider oldCollider = GetComponent<Collider>();
        if (oldCollider == null) return;

        Bounds local = default;
        bool any = false;

        foreach (Transform child in transform)
        {
            if (!child.name.StartsWith("Piece_")) continue;

            Vector3 c = child.localPosition;
            Vector3 size = new Vector3(Mathf.Abs(child.localScale.x), Mathf.Abs(child.localScale.y), 0.1f);
            Bounds b = new Bounds(c, size);

            if (!any) { local = b; any = true; }
            else local.Encapsulate(b);
        }

        if (!any) return;

        Destroy(oldCollider);
        BoxCollider box = gameObject.AddComponent<BoxCollider>();
        box.center = local.center;
        box.size = local.size + new Vector3(0.05f, 0.05f, 0.05f);
    }

    private IEnumerator ChopPulse()
    {
        Vector3 s = BaseLocalScale;
        float dur = 0.05f;
        float t = 0f;

        while (t < dur)
        {
            t += Time.deltaTime;
            transform.localScale = new Vector3(s.x, s.y * Mathf.Lerp(1f, 0.85f, t / dur), s.z);
            yield return null;
        }

        t = 0f;
        while (t < dur)
        {
            t += Time.deltaTime;
            transform.localScale = new Vector3(s.x, s.y * Mathf.Lerp(0.85f, 1f, t / dur), s.z);
            yield return null;
        }

        transform.localScale = s;
    }
}

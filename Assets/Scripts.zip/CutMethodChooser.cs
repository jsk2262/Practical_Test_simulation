using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class CutMethodChooser : MonoBehaviour
{
    public static CutMethodChooser Instance { get; private set; }

    private const float Step = 0.1f;
    private const float MinCm = 0.1f;
    private const float MaxCm = 5f;

    private static readonly Color ValueBgIdle = new Color(0.95f, 0.95f, 0.9f);
    private static readonly Color ValueBgEditing = new Color(1f, 0.92f, 0.55f);

    private GameObject methodPanel;
    private GameObject specPanel;
    private Action<IngredientItem.CutMethod, CutSpec> onChosen;
    private IngredientItem.CutMethod pendingMethod;
    private Vector3 shownPos;

    private float curWidth, curLength, curThickness;

    // Indexed 0=가로 1=세로 2=폭 - lets the click-to-type editor and the -/+
    // steppers share the same read/write/refresh plumbing per row.
    private readonly Func<float>[] rowGetters = new Func<float>[3];
    private readonly Action<float>[] rowSetters = new Action<float>[3];
    private readonly TextMesh[] rowValueTexts = new TextMesh[3];
    private readonly Renderer[] rowValueBgRenderers = new Renderer[3];

    private int editingRow = -1;
    private string editBuffer = "";

    void Awake()
    {
        Instance = this;
    }

    void Update()
    {
        if (editingRow < 0) return;
        Keyboard kb = Keyboard.current;
        if (kb == null) return;

        if (kb.backspaceKey.wasPressedThisFrame && editBuffer.Length > 0)
        {
            editBuffer = editBuffer.Substring(0, editBuffer.Length - 1);
            UpdateEditDisplay();
        }

        if (kb.enterKey.wasPressedThisFrame || kb.numpadEnterKey.wasPressedThisFrame)
        {
            CommitEdit();
        }
        else if (kb.escapeKey.wasPressedThisFrame)
        {
            CancelEdit();
        }
    }

    public void Show(Vector3 worldPos, Action<IngredientItem.CutMethod, CutSpec> callback)
    {
        CommitEdit();
        onChosen = callback;
        shownPos = worldPos;

        if (methodPanel == null) BuildMethodPanel();
        if (specPanel == null) BuildSpecPanel();

        methodPanel.transform.position = worldPos;
        methodPanel.SetActive(true);
        specPanel.SetActive(false);
    }

    private void BuildMethodPanel()
    {
        methodPanel = new GameObject("CutMethodPanel");
        methodPanel.transform.SetParent(transform, false);

        CreateQuad(methodPanel.transform, "Background", new Vector3(0f, 0f, -0.02f), new Vector2(6.2f, 1.2f), new Color(0.9f, 0.88f, 0.8f, 0.95f));

        // "그외" covers anything that doesn't fit the three named methods (a
        // custom dice-like or triangular spec, etc.) - it skips straight to
        // the free-entry 가로/세로/폭 screen just like the others do, just
        // without presupposing a particular shape.
        CreateMethodButton("그외", new Vector3(-2.25f, 0f, -0.1f), IngredientItem.CutMethod.Other);
        CreateMethodButton("채썰기", new Vector3(-0.75f, 0f, -0.1f), IngredientItem.CutMethod.Julienne);
        CreateMethodButton("편썰기", new Vector3(0.75f, 0f, -0.1f), IngredientItem.CutMethod.Slice);
        CreateMethodButton("다지기", new Vector3(2.25f, 0f, -0.1f), IngredientItem.CutMethod.Dice);

        methodPanel.SetActive(false);
    }

    private void BuildSpecPanel()
    {
        specPanel = new GameObject("SpecPanel");
        specPanel.transform.SetParent(transform, false);

        CreateQuad(specPanel.transform, "Background", new Vector3(0f, 0f, -0.02f), new Vector2(6.4f, 3.4f), new Color(0.9f, 0.88f, 0.8f, 0.95f));

        CreateSpecRow(0, 0.9f, "가로", () => curWidth, v => curWidth = v);
        CreateSpecRow(1, 0.1f, "세로", () => curLength, v => curLength = v);
        CreateSpecRow(2, -0.7f, "폭", () => curThickness, v => curThickness = v);

        CreateActionButton(specPanel.transform, "자르기", new Vector3(0f, -1.5f, -0.1f), () => { CommitEdit(); ConfirmSpec(); });

        CreateLabel(specPanel.transform, "숫자를 클릭하면 직접 입력할 수 있어요 (Enter 확정 / Esc 취소)",
            new Vector3(0f, -2.5f, -0.1f), 14, new Color(0.35f, 0.35f, 0.35f), TextAnchor.MiddleCenter);

        specPanel.SetActive(false);
    }

    /// <summary>One 가로/세로/폭 row: a label, a -/+ stepper pair, and a live cm
    /// readout that's itself a button - clicking it opens click-to-type entry
    /// for when the -/+ step (0.1cm) would take too many clicks to reach a very
    /// different value.</summary>
    private void CreateSpecRow(int index, float y, string label, Func<float> get, Action<float> set)
    {
        rowGetters[index] = get;
        rowSetters[index] = set;

        CreateLabel(specPanel.transform, label, new Vector3(-3.0f, y, -0.1f), 26, Color.black, TextAnchor.MiddleLeft);

        GameObject valueBtn = CreateActionButton(specPanel.transform, get().ToString("0.0") + "cm", new Vector3(-0.3f, y, -0.1f),
            () => BeginEdit(index), new Vector2(1.5f, 0.5f));
        rowValueTexts[index] = valueBtn.GetComponentInChildren<TextMesh>();
        rowValueBgRenderers[index] = valueBtn.GetComponent<Renderer>();

        CreateActionButton(specPanel.transform, "-", new Vector3(-1.6f, y, -0.1f), () =>
        {
            CommitEdit();
            set(Mathf.Clamp(get() - Step, MinCm, MaxCm));
            RefreshRow(index);
        }, new Vector2(0.4f, 0.4f));

        CreateActionButton(specPanel.transform, "+", new Vector3(1.1f, y, -0.1f), () =>
        {
            CommitEdit();
            set(Mathf.Clamp(get() + Step, MinCm, MaxCm));
            RefreshRow(index);
        }, new Vector2(0.4f, 0.4f));
    }

    private void RefreshRow(int index)
    {
        rowValueTexts[index].text = rowGetters[index]().ToString("0.0") + "cm";
    }

    private void BeginEdit(int row)
    {
        if (editingRow == row) return;
        CommitEdit();

        editingRow = row;
        editBuffer = rowGetters[row]().ToString("0.0");
        rowValueBgRenderers[row].material.color = ValueBgEditing;
        if (Keyboard.current != null) Keyboard.current.onTextInput += OnTextInput;
        UpdateEditDisplay();
    }

    private void OnTextInput(char c)
    {
        if (editingRow < 0) return;

        if (char.IsDigit(c))
        {
            if (editBuffer.Length < 6) editBuffer += c;
        }
        else if (c == '.' && !editBuffer.Contains("."))
        {
            editBuffer += c;
        }
        else
        {
            return;
        }

        UpdateEditDisplay();
    }

    private void UpdateEditDisplay()
    {
        rowValueTexts[editingRow].text = (editBuffer.Length > 0 ? editBuffer : "0") + "cm|";
    }

    private void CommitEdit()
    {
        if (editingRow < 0) return;
        int row = editingRow;

        if (float.TryParse(editBuffer, out float parsed))
        {
            rowSetters[row](Mathf.Clamp(parsed, MinCm, MaxCm));
        }

        StopEditingInput(row);
        RefreshRow(row);
    }

    private void CancelEdit()
    {
        if (editingRow < 0) return;
        int row = editingRow;

        StopEditingInput(row);
        RefreshRow(row);
    }

    private void StopEditingInput(int row)
    {
        if (Keyboard.current != null) Keyboard.current.onTextInput -= OnTextInput;
        rowValueBgRenderers[row].material.color = ValueBgIdle;
        editingRow = -1;
        editBuffer = "";
    }

    private GameObject CreateActionButton(Transform parent, string label, Vector3 localPos, Action onClick, Vector2 size = default)
    {
        if (size == default) size = new Vector2(1.3f, 0.5f);

        GameObject btn = GameObject.CreatePrimitive(PrimitiveType.Quad);
        btn.name = "Btn_" + label.Replace("\n", "_");
        btn.transform.SetParent(parent, false);
        btn.transform.localPosition = localPos;
        btn.transform.localScale = new Vector3(size.x, size.y, 1f);

        Material mat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        mat.color = new Color(0.95f, 0.95f, 0.9f, 1f);
        btn.GetComponent<Renderer>().material = mat;

        TextMesh tm = CreateLabel(btn.transform, label, new Vector3(0f, 0f, -0.05f), 28, Color.black, TextAnchor.MiddleCenter);
        // Undo the button's own non-uniform scale so the label renders at its
        // real size instead of being squashed by the quad's local scale.
        tm.transform.localScale = new Vector3(1f / size.x, 1f / size.y, 1f);

        btn.AddComponent<SimpleActionButton>().Init(onClick);
        return btn;
    }

    private void CreateMethodButton(string label, Vector3 localOffset, IngredientItem.CutMethod method)
    {
        CreateActionButton(methodPanel.transform, label, localOffset, () => Choose(method), new Vector2(1.3f, 0.6f));
    }

    private TextMesh CreateLabel(Transform parent, string text, Vector3 localPos, int fontSize, Color color, TextAnchor anchor)
    {
        GameObject go = new GameObject("Label");
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPos;

        TextMesh tm = go.AddComponent<TextMesh>();
        tm.text = text;
        tm.fontSize = fontSize;
        tm.characterSize = 0.16f;
        tm.anchor = anchor;
        tm.color = color;
        return tm;
    }

    private void CreateQuad(Transform parent, string name, Vector3 localPos, Vector2 size, Color color)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Quad);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPos;
        go.transform.localScale = new Vector3(size.x, size.y, 1f);

        Material mat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        mat.color = color;
        go.GetComponent<Renderer>().sharedMaterial = mat;
        UnityEngine.Object.Destroy(go.GetComponent<Collider>());
    }

    public void Choose(IngredientItem.CutMethod method)
    {
        CommitEdit();
        pendingMethod = method;
        methodPanel.SetActive(false);

        CutSpec defaultSpec = IngredientItem.BuildSpec(method, IngredientItem.ReferenceThicknessCm(method));
        curWidth = defaultSpec.widthCm;
        curLength = defaultSpec.lengthCm;
        curThickness = defaultSpec.thicknessCm;
        RefreshRow(0);
        RefreshRow(1);
        RefreshRow(2);

        specPanel.transform.position = shownPos;
        specPanel.SetActive(true);
    }

    private void ConfirmSpec()
    {
        specPanel.SetActive(false);
        Action<IngredientItem.CutMethod, CutSpec> callback = onChosen;
        onChosen = null;

        CutSpec spec = new CutSpec(curWidth, curLength, curThickness);
        callback?.Invoke(pendingMethod, spec);
    }
}

using System.Collections;
using UnityEngine;

/// <summary>
/// A small clickable spot near the cutting board's corner - clicking it flips
/// the board immediately (CuttingBoardController.Flip()) and pops up a
/// translucent "뒤집기" toast in the empty counter space below the board as
/// feedback, which fades out on its own a moment later.
/// </summary>
public class CuttingBoardFlipZone : MonoBehaviour, IClickable
{
    [SerializeField] private CuttingBoardController board;

    /// <summary>Offset from this zone down into the empty counter space below
    /// the board - the board's own Y extent varies as it gets repositioned, so
    /// this is a small downward nudge from wherever the zone itself already
    /// sits (already low, near the board's bottom edge) rather than a fixed
    /// world position.</summary>
    [SerializeField] private Vector3 promptOffset = new Vector3(0f, -0.55f, -0.2f);
    [SerializeField] private float promptVisibleSeconds = 1f;

    private GameObject promptRoot;
    private Coroutine hideRoutine;

    void Awake()
    {
        BuildMarker();
    }

    /// <summary>This trigger has no visual of its own - just an invisible
    /// collider - so without some persistent marker there's nothing telling
    /// the player it's here to click. A small shimmering dot sits on top of
    /// it as that affordance.</summary>
    private void BuildMarker()
    {
        GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Quad);
        marker.name = "FlipMarker";
        marker.transform.SetParent(transform, false);
        marker.transform.localPosition = new Vector3(0f, 0f, -0.1f);
        marker.transform.localScale = new Vector3(0.3f, 0.3f, 1f);
        Object.Destroy(marker.GetComponent<Collider>());

        Material mat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        mat.SetFloat("_Surface", 1f);
        mat.SetOverrideTag("RenderType", "Transparent");
        mat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        mat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        mat.SetInt("_ZWrite", 0);
        mat.DisableKeyword("_ALPHATEST_ON");
        mat.EnableKeyword("_ALPHABLEND_ON");
        mat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
        mat.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
        mat.color = new Color(1f, 0.95f, 0.6f, 0.7f);
        marker.GetComponent<Renderer>().material = mat;

        marker.AddComponent<ShimmerEffect>();
    }

    public void OnClicked()
    {
        board?.Flip();
        ShowToast();
    }

    private void ShowToast()
    {
        if (promptRoot == null) BuildPrompt();
        promptRoot.transform.position = transform.position + promptOffset;
        promptRoot.SetActive(true);

        if (hideRoutine != null) StopCoroutine(hideRoutine);
        hideRoutine = StartCoroutine(HideAfterDelay());
    }

    private IEnumerator HideAfterDelay()
    {
        yield return new WaitForSeconds(promptVisibleSeconds);
        promptRoot.SetActive(false);
        hideRoutine = null;
    }

    /// <summary>Feedback toast only - no confirm button, since the flip already
    /// happened the moment the marker was clicked. Translucent (background
    /// alpha well below the marker's own 0.7) so it reads as a passing status
    /// note, not a dialog demanding attention.</summary>
    private void BuildPrompt()
    {
        promptRoot = new GameObject("FlipPrompt");
        promptRoot.transform.SetParent(transform, false);

        GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Quad);
        bg.name = "Background";
        bg.transform.SetParent(promptRoot.transform, false);
        bg.transform.localPosition = new Vector3(0f, 0f, 0.02f);
        bg.transform.localScale = new Vector3(1.3f, 0.5f, 1f);
        Material bgMat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        bgMat.SetFloat("_Surface", 1f);
        bgMat.SetOverrideTag("RenderType", "Transparent");
        bgMat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        bgMat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        bgMat.SetInt("_ZWrite", 0);
        bgMat.DisableKeyword("_ALPHATEST_ON");
        bgMat.EnableKeyword("_ALPHABLEND_ON");
        bgMat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
        bgMat.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
        bgMat.color = new Color(0.9f, 0.88f, 0.8f, 0.5f);
        bg.GetComponent<Renderer>().material = bgMat;
        Object.Destroy(bg.GetComponent<Collider>());

        GameObject labelGo = new GameObject("Label");
        labelGo.transform.SetParent(promptRoot.transform, false);
        labelGo.transform.localPosition = new Vector3(0f, 0f, -0.02f);
        TextMesh tm = labelGo.AddComponent<TextMesh>();
        tm.text = "뒤집기";
        tm.fontSize = 28;
        tm.characterSize = 0.16f;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.color = new Color(0.15f, 0.15f, 0.15f, 0.85f);

        promptRoot.SetActive(false);
    }
}

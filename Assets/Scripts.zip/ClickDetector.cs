using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Manual click + drag detection for the new Input System. Unity's legacy
/// OnMouseDown/OnMouseDrag never fire when Active Input Handling is set to
/// "Input System Package (New)" only, so this replaces both with explicit
/// raycasts driven off Mouse.current. A press that barely moves resolves as a
/// click; a press that moves past dragThreshold resolves as a drag - so the
/// same object (e.g. the wok) can support both "click to place" and "drag to
/// shake" without one gesture stealing the other's presses.
///
/// Press and release are checked independently (no early-return between them)
/// so a very quick click - press and release landing in the same frame - still
/// resolves; returning early after handling the press alone used to swallow
/// those clicks entirely.
/// </summary>
public class ClickDetector : MonoBehaviour
{
    [SerializeField] private Camera targetCamera;
    [SerializeField] private float maxDistance = 100f;
    [SerializeField] private float dragThreshold = 6f;

    private GameObject pressedTarget;
    private Vector2 pressStartPos;
    private Vector2 lastMousePos;
    private bool isDragging;
    private bool isPressing;
    private bool dragChecked;
    private IDraggable activeDraggable;
    private int raycastMask;

    void Awake()
    {
        if (targetCamera == null) targetCamera = Camera.main;

        // The hand cursor model (HandCursor and its finger/palm/outline parts) sits
        // on the "Ignore Raycast" layer - without excluding it here, a click aimed
        // at whatever the hand happens to be resting on top of (including a held
        // item's intended target) can hit the hand's own collider first and resolve
        // to nothing, since the hand itself implements neither IClickable nor
        // IDraggable.
        raycastMask = ~(1 << LayerMask.NameToLayer("Ignore Raycast"));
    }

    void Update()
    {
        Mouse mouse = Mouse.current;
        if (mouse == null || targetCamera == null) return;

        if (HandCarry.Instance != null && HandCarry.Instance.IsLocked)
        {
            pressedTarget = null;
            isPressing = false;
            isDragging = false;
            activeDraggable = null;
            return;
        }

        if (!mouse.leftButton.isPressed)
        {
            UpdateHoverHighlight(mouse.position.ReadValue());
        }

        if (mouse.leftButton.wasPressedThisFrame)
        {
            Vector2 screenPos = mouse.position.ReadValue();
            Ray ray = targetCamera.ScreenPointToRay(screenPos);

            pressedTarget = Physics.Raycast(ray, out RaycastHit hit, maxDistance, raycastMask)
                ? hit.collider.gameObject
                : null;
            // While something is in hand a press counts even over empty space,
            // so the held item can be dragged out from anywhere.
            isPressing = pressedTarget != null || HandCarry.Instance?.Current != null;
            pressStartPos = screenPos;
            lastMousePos = screenPos;
            isDragging = false;
            dragChecked = false;
            activeDraggable = null;
        }

        if (isPressing && mouse.leftButton.isPressed)
        {
            Vector2 pos = mouse.position.ReadValue();

            if (!dragChecked && Vector2.Distance(pos, pressStartPos) >= dragThreshold)
            {
                dragChecked = true;
                activeDraggable = StartDrag();
                isDragging = activeDraggable != null;
            }

            if (isDragging) activeDraggable.OnDragMove(pos - lastMousePos, Time.deltaTime);

            lastMousePos = pos;
        }

        if (isPressing && mouse.leftButton.wasReleasedThisFrame)
        {
            if (isDragging)
            {
                activeDraggable.OnDragEnd();
            }
            else
            {
                // Includes a press that wobbled past dragThreshold on something
                // that refused the drag - it still lands as the click it was.
                IClickable clickable = pressedTarget != null ? pressedTarget.GetComponentInParent<IClickable>() : null;
                if (clickable != null) clickable.OnClicked();
                else DropHeldAt(mouse.position.ReadValue());
            }

            pressedTarget = null;
            isPressing = false;
            isDragging = false;
            activeDraggable = null;
        }
    }

    /// <summary>A click on empty counter (nothing interactable under the cursor)
    /// while holding something sets it down right there.</summary>
    private void DropHeldAt(Vector2 screenPos)
    {
        HandCarry hand = HandCarry.Instance;
        if (hand == null || hand.Current == null) return;

        float depth = hand.Current.RestZ - targetCamera.transform.position.z;
        Vector3 world = targetCamera.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, depth));
        if (hand.PlaceFreeAt(world))
            HandController.Instance?.GoTo(world + new Vector3(0f, 0f, -0.55f), null);
    }

    /// <summary>Starts a drag on whatever was pressed; if that refuses (a
    /// Carryable while the hand already holds something else - the common case
    /// of pressing on the drop target itself while holding a bowl), the drag
    /// goes to the held item instead, so it follows the cursor and drops
    /// wherever it's released. Previously that press was swallowed entirely:
    /// neither a drag nor a click, and the bowl stayed stuck in hand.</summary>
    private IDraggable StartDrag()
    {
        IDraggable pressed = pressedTarget != null ? pressedTarget.GetComponentInParent<IDraggable>() : null;
        if (pressed != null && pressed.OnDragStart()) return pressed;

        IDraggable held = HandCarry.Instance != null ? HandCarry.Instance.Current : null;
        if (held != null && held != pressed && held.OnDragStart()) return held;

        return null;
    }

    /// <summary>Lights up whatever's under the cursor while idle (mouse not
    /// pressed) - a "this is what you're about to grab" cue shown before the
    /// click, distinct from DropHighlightRing's other job of marking a valid
    /// drop target while something is already being dragged. Reuses the same
    /// ring since the two situations never overlap (this only runs when the
    /// button is up; the drag-highlight only runs while it's held).</summary>
    private void UpdateHoverHighlight(Vector2 screenPos)
    {
        DropHighlightRing ring = DropHighlightRing.Instance;
        if (ring == null) return;

        Ray ray = targetCamera.ScreenPointToRay(screenPos);
        if (Physics.Raycast(ray, out RaycastHit hit, maxDistance, raycastMask))
        {
            Interactable target = hit.collider.GetComponentInParent<Interactable>();
            if (target != null)
            {
                ring.Show(target.transform);
                return;
            }
        }

        ring.Hide();
    }
}

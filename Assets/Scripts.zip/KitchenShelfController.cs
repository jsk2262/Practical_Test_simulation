using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// A tool-storage shelf (the pot/pan rack) that accepts a fixed, explicitly
/// listed set of items - unlike SauceShelfController's "any SeasoningBottle"
/// policy, a plate or bowl full of ingredients shouldn't end up parked here,
/// so membership is by direct reference rather than by type. Several of these
/// can share the same allowed-items list so any one of them can receive
/// whichever item the player is currently carrying.
/// </summary>
public class KitchenShelfController : Interactable, ISlotContainer
{
    [SerializeField] private float halfWidth = 0.6f;
    [SerializeField] private Carryable[] allowedItems;

    private Transform contentRoot;

    private Transform ContentRoot
    {
        get
        {
            if (contentRoot == null)
            {
                Transform existing = transform.Find("ContentRoot");
                if (existing != null)
                {
                    contentRoot = existing;
                }
                else
                {
                    var go = new GameObject("ContentRoot");
                    contentRoot = go.transform;
                    contentRoot.SetParent(transform, false);

                    Vector3 s = transform.lossyScale;
                    contentRoot.localScale = new Vector3(
                        Mathf.Approximately(s.x, 0f) ? 1f : 1f / s.x,
                        Mathf.Approximately(s.y, 0f) ? 1f : 1f / s.y,
                        Mathf.Approximately(s.z, 0f) ? 1f : 1f / s.z);
                    contentRoot.rotation = Quaternion.identity;
                }
            }

            return contentRoot;
        }
    }

    private bool IsAllowed(Carryable item)
    {
        if (item == null || allowedItems == null) return false;
        foreach (Carryable a in allowedItems)
            if ((object)a == item) return true;
        return false;
    }

    public override bool CanAcceptDrop(Carryable item) => IsAllowed(item);

    protected override void Activate()
    {
        HandCarry hand = HandCarry.Instance;
        Carryable item = hand?.Current;
        if (!IsAllowed(item)) return;

        Transform root = ContentRoot;

        // Same reasoning as CuttingBoardController/SauceShelfController - a
        // plain click carries no aim, so it lands centered; only a real drag
        // has a position worth honoring.
        Vector3 desired = hand.DropIsFromDrag
            ? root.InverseTransformPoint(item.transform.position)
            : Vector3.zero;

        Vector3 clamped = new Vector3(Mathf.Clamp(desired.x, -halfWidth, halfWidth), 0f, 0f);

        if (hand.PlaceAtFreeLocalPosition(root, clamped))
            item.CurrentContainer = this;
    }

    public void Release(Carryable item)
    {
        // No single-occupant slot to clear - each item just tracks itself.
    }
}

using System.Collections;
using UnityEngine;

/// <summary>
/// A shelf seasoning bottle (설탕/소금/식초 etc). Picking it up and dropping it back
/// on the shelf just repositions it there. "Using" it - dropping it onto an
/// ingredient or a bowl - measures one spoonful instead of pouring straight
/// in: the scene's measuring spoon is summoned, the bottle tips while the
/// spoon dips in and comes back out loaded, the bottle goes back to its spot
/// on the SauceShelf, and the hand ends up holding the loaded spoon, ready to
/// be tipped into whatever it's used on next.
/// </summary>
public class SeasoningBottle : Carryable
{
    [SerializeField] private string seasoningName = "조미료";

    [Header("Scoop gesture")]
    [SerializeField] private float tiltAngle = 40f;

    public string SeasoningName => seasoningName;

    /// <summary>True while the scoop sequence is playing.</summary>
    public bool IsScooping { get; private set; }

    private SauceShelfController shelfHome;
    private Vector3 shelfHomeLocal;

    /// <summary>Set by the shelf when this bottle is taken off it - where to
    /// send it back after a scoop.</summary>
    public void SetShelfHome(SauceShelfController shelf, Vector3 localPosition)
    {
        shelfHome = shelf;
        shelfHomeLocal = localPosition;
    }

    /// <summary>An empty measuring spoon, held in hand, clicking this bottle
    /// (wherever it happens to be resting) scoops one dose from it - the real
    /// exam move of measuring out a spoonful rather than pouring straight from
    /// the bottle.</summary>
    protected override void OnClickedWhileHandFull(Carryable held)
    {
        if (held is ToolItem spoon && spoon.Kind == ToolKind.MeasuringSpoon && !spoon.IsSpoonLoaded)
        {
            spoon.LoadSeasoning(seasoningName);
            return;
        }

        // Clicking another bottle on the shelf while holding one means "put it
        // here", not "use it on this bottle" - hand it to the shelf.
        if (held is SeasoningBottle && CurrentContainer is SauceShelfController shelf)
        {
            shelf.ForceActivate();
        }
    }

    public override bool CanAcceptDrop(Carryable item) =>
        item is ToolItem spoon && spoon.Kind == ToolKind.MeasuringSpoon && !spoon.IsSpoonLoaded;

    /// <summary>Starts the scoop sequence (bottle held, used on something).
    /// Returns false if it can't run - no measuring spoon in the scene, no
    /// shelf spot to return to, or one already playing.</summary>
    public bool TryScoopWithSpoon()
    {
        HandCarry hand = HandCarry.Instance;
        ToolItem spoon = ToolItem.MeasuringSpoon;
        if (IsScooping || hand == null || hand.Current != this) return false;

        if (spoon == null || !spoon.isActiveAndEnabled)
        {
            Debug.LogWarning("[SeasoningBottle] No measuringSpoon (ToolItem, kind MeasuringSpoon) in the scene - run Tools/Kitchen/Setup Measuring Spoon.");
            return false;
        }
        if (shelfHome == null) return false;

        StartCoroutine(ScoopRoutine(hand, spoon));
        return true;
    }

    private IEnumerator ScoopRoutine(HandCarry hand, ToolItem spoon)
    {
        IsScooping = true;
        hand.IsLocked = true;

        Renderer bottleRend = GetComponent<Renderer>();
        float height = bottleRend != null ? Mathf.Max(bottleRend.bounds.size.y, 0.2f) : 0.6f;

        // Summon the spoon: off whatever it was resting on, colliders quiet,
        // at its own true size and resting rotation.
        spoon.CurrentContainer?.Release(spoon);
        spoon.CurrentContainer = null;
        spoon.transform.SetParent(null, true);
        spoon.transform.rotation = spoon.BaseRotation;
        // Only the ones enabled now - a permanently-off leftover must stay off.
        Collider[] spoonColliders = System.Array.FindAll(spoon.GetComponentsInChildren<Collider>(), c => c.enabled);
        foreach (Collider c in spoonColliders) c.enabled = false;

        Vector3 spoonScale = spoon.BaseLocalScale;
        Vector3 SpoonSide() => transform.position + new Vector3(height * 0.9f, height * 0.75f, -0.1f);

        // 1) Spoon pops in beside the bottle.
        yield return Animate(0.2f, t =>
        {
            spoon.transform.position = SpoonSide();
            spoon.transform.localScale = spoonScale * t;
        });

        // 2) Bottle tips toward the spoon; the spoon moves over its mouth.
        Quaternion tilt = Quaternion.Euler(0f, 0f, -tiltAngle);
        Quaternion spoonDip = Quaternion.Euler(0f, 0f, 35f) * spoon.BaseRotation;
        Vector3 side = SpoonSide();
        yield return Animate(0.3f, t =>
        {
            SetTempHoldRotation(Quaternion.Slerp(Quaternion.identity, tilt, t));
            spoon.transform.position = Vector3.Lerp(side, Mouth(height, tilt, 0.1f), t);
            spoon.transform.rotation = Quaternion.Slerp(spoon.BaseRotation, spoonDip, t);
        });

        // 3) Dip in, scoop, pull back out - loaded on the way out.
        yield return Animate(0.2f, t => spoon.transform.position = Vector3.Lerp(Mouth(height, tilt, 0.1f), Mouth(height, tilt, -0.3f), t));
        spoon.ConsumeSeasoning();
        spoon.LoadSeasoning(seasoningName);
        spoon.transform.localScale = spoonScale * 1.15f; // LoadSeasoning's own bulge, relative to true size
        yield return Animate(0.2f, t => spoon.transform.position = Vector3.Lerp(Mouth(height, tilt, -0.3f), Mouth(height, tilt, 0.25f), t));

        // 4) Bottle rights itself and flies home to the shelf; the loaded spoon
        //    comes over to where the hand holds things.
        Vector3 spoonFrom = spoon.transform.position;
        Vector3 bottleHome = shelfHome.ShelfWorldPoint(shelfHomeLocal);
        Vector3 handHold = hand.transform.position + spoon.HandHoldOffset;
        yield return Animate(0.35f, t =>
        {
            SetTempHoldRotation(Quaternion.Slerp(tilt, Quaternion.identity, t));
            // Extra offset from where the hand normally holds it, growing until
            // the bottle sits exactly on its shelf spot.
            Vector3 heldAt = hand.transform.position + BaseHandHoldOffset;
            SetTempHoldOffset((bottleHome - heldAt) * t);
            spoon.transform.position = Vector3.Lerp(spoonFrom, handHold, t);
            spoon.transform.rotation = Quaternion.Slerp(spoonDip, spoon.BaseRotation, t);
        });

        SetTempHoldRotation(Quaternion.identity);
        SetTempHoldOffset(Vector3.zero);
        foreach (Collider c in spoonColliders) if (c != null) c.enabled = true;

        // Trade: bottle back on its shelf spot, spoon into the hand.
        shelfHome.ReturnBottle(this, shelfHomeLocal);
        hand.PickUp(spoon);
        spoon.transform.localScale = spoonScale * 1.15f;

        hand.IsLocked = false;
        IsScooping = false;
    }

    /// <summary>Bottles are base-pivoted, so the mouth sits one bottle-height up
    /// the bottle's own (tilted) axis; depth &lt; 0 goes down inside the neck.</summary>
    private Vector3 Mouth(float height, Quaternion tilt, float depth) =>
        transform.position + tilt * Vector3.up * (height * (0.95f + depth)) + new Vector3(0f, 0f, -0.1f);

    private static IEnumerator Animate(float duration, System.Action<float> step)
    {
        for (float e = 0f; e < duration; e += Time.deltaTime)
        {
            float t = e / duration;
            step(t * t * (3f - 2f * t));
            yield return null;
        }
        step(1f);
    }

    public override void OnPlaced()
    {
        base.OnPlaced();
        SetTempHoldRotation(Quaternion.identity);
        SetTempHoldOffset(Vector3.zero);
    }
}

using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// One draggable, semi-transparent "step card" window in the cooking-plan sequence
/// board. Drag it onto a numbered slot to place it in the plan; drag it off again
/// (or onto empty pool space) to send it back to its pool spot. Whenever
/// CookingPlanManager finds a later-phase step already sitting earlier in the
/// board than this one, it marks this card invalid and it turns red - clicking a
/// red card shows why.
/// </summary>
public class PlanStepCard : MonoBehaviour, IDraggable, IClickable
{
    // Brighter and more opaque than a "true" translucent window would be -
    // black text needs that much contrast to stay legible over the dark panel
    // backdrop showing through.
    public static readonly Color ValidColor = new Color(0.72f, 0.85f, 0.98f, 0.88f);
    public static readonly Color InvalidColor = new Color(0.98f, 0.45f, 0.42f, 0.9f);

    private CookingPlanManager owner;
    private Material mat;
    private Vector3 poolHomeLocalPos;
    private bool isDragging;
    private Camera cam;

    public string Label { get; private set; }
    public int Phase { get; private set; }
    public int SlotIndex { get; private set; } = -1;
    public bool IsInvalid { get; private set; }
    public PlanStepCard BlockedBy { get; private set; }

    public void Init(CookingPlanManager owner, string label, int phase, Material mat, Vector3 poolHomeLocalPos)
    {
        this.owner = owner;
        this.mat = mat;
        this.poolHomeLocalPos = poolHomeLocalPos;
        Label = label;
        Phase = phase;
    }

    public void SetSlot(int index)
    {
        SlotIndex = index;
    }

    /// <summary>Sends the card back to its scattered starting spot in the pool -
    /// used both when a drag misses every slot and when another card displaces
    /// this one out of its slot.</summary>
    public void ReturnToPool()
    {
        SlotIndex = -1;
        transform.localPosition = poolHomeLocalPos;
    }

    public void SetValidity(bool invalid, PlanStepCard blockedBy)
    {
        IsInvalid = invalid;
        BlockedBy = blockedBy;
        mat.color = invalid ? InvalidColor : ValidColor;
    }

    public bool OnDragStart()
    {
        isDragging = true;
        cam = Camera.main;

        // Bump toward the camera while dragging so this card draws in front of
        // every other card and slot instead of z-fighting/hiding behind them.
        Vector3 p = transform.localPosition;
        transform.localPosition = new Vector3(p.x, p.y, -0.3f);
        return true;
    }

    public void OnDragMove(Vector2 mouseDelta, float deltaTime)
    {
        if (!isDragging || cam == null || Mouse.current == null) return;

        Vector2 screenPos = Mouse.current.position.ReadValue();
        float depth = transform.position.z - cam.transform.position.z;
        Vector3 world = cam.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, depth));
        transform.position = new Vector3(world.x, world.y, transform.position.z);
    }

    public void OnDragEnd()
    {
        isDragging = false;
        owner.OnCardDropped(this);
    }

    public void OnClicked()
    {
        if (IsInvalid) owner.ShowExplanation(this);
    }
}

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// A bowl/dish that can itself be picked up and carried (like a tool), while also
/// acting as a container that holds several ingredients freely across its surface -
/// like a real plate, items land near wherever they're dropped instead of snapping
/// into a fixed row of slots. If that spot is already taken (a player dragging
/// several things just aims at "the plate" each time, not a precise sub-position),
/// the new item is nudged to the nearest free spot instead of stacking exactly on
/// top of - and fully hiding - whatever's already there. Whatever is sitting in the
/// bowl moves with it since ingredients are parented under it.
/// </summary>
public class MovableBowl : Carryable, ISlotContainer
{
    [SerializeField] private SlotAccepts accepts = SlotAccepts.IngredientOnly;
    [SerializeField] private int capacity = 6;

    /// <summary>Only a deep dish (a real bowl, not a flat plate) makes sense to fill
    /// with water - set on the bowlSize variants, left off on the flat plateSize ones.</summary>
    [SerializeField] private bool canHoldWater = false;
    public bool CanHoldWater => canHoldWater;

    public bool IsFilledWithWater { get; private set; }
    private GameObject waterVisual;

    [Header("Boiling (water-filled vessels on a lit burner)")]
    [SerializeField] private float timeToBoilNoLid = 15f;
    [SerializeField] private float timeToBoilWithLid = 8f;
    [SerializeField] private GameObject bubbleEffectPrefab;

    /// <summary>True once this vessel's water has been on a lit burner long
    /// enough to boil - a lid on top (see PotLid/HasLid) shortens that wait,
    /// the real-kitchen reason to actually put a lid on. Purely about the
    /// water itself, separate from CookableItem's own per-ingredient cook
    /// timer.</summary>
    public bool IsBoiling { get; private set; }
    private float boilProgress;
    private GameObject bubbleInstance;

    [Header("Water look")]
    /// <summary>Optional - a material using Kitchen/PotWater. Left empty, one is
    /// made from that shader at runtime (fine in the editor; assign it here for
    /// builds so the shader actually gets included).</summary>
    [SerializeField] private Material waterMaterial;
    /// <summary>Water disc diameter as a fraction of the vessel body's outer
    /// diameter - the water sits inside the wall, not over the rim.</summary>
    [SerializeField, Range(0.5f, 1f)] private float waterInnerRatio = 0.86f;
    /// <summary>Surface height once full, as a fraction of the vessel's own
    /// height (0 = bottom, 1 = rim) - every vessel fills to about half.</summary>
    [SerializeField, Range(0.1f, 1f)] private float fullWaterLevel = 0.5f;
    /// <summary>Seconds under a running faucet to fill from empty to full.</summary>
    [SerializeField] private float secondsToFill = 3f;

    /// <summary>0 = empty, 1 = full (at fullWaterLevel). Rises while under a
    /// running WaterTap; the vessel only counts as filled (and can boil) at 1.</summary>
    public float WaterAmount { get; private set; }

    private Vector3 waterBottomLocal;
    private Vector3 waterTopLocal;
    private float waterDiameter;
    private float waterThickness;
    /// <summary>Manual nudge in this vessel's own local space, for a model whose
    /// pivot isn't at the center of its round body.</summary>
    [SerializeField] private Vector3 waterLocalOffset;
    /// <summary>How fast the visible heat/boil fades in and out (per second).</summary>
    [SerializeField] private float waterLookSpeed = 0.6f;
    /// <summary>Resting slosh (0-1) - still water isn't perfectly dead flat.</summary>
    [SerializeField, Range(0f, 1f)] private float idleSlosh = 0.2f;

    private static readonly int HeatId = Shader.PropertyToID("_Heat");
    private static readonly int BoilId = Shader.PropertyToID("_Boil");
    private static readonly int SloshId = Shader.PropertyToID("_Slosh");
    private Material waterMaterialInstance;
    private float shownHeat;
    private float shownBoil;
    private float shownSlosh;

    /// <summary>Half-extents (in real-world-like units, not the plate's own squashed
    /// local scale) an item may land within, measured from the plate's center.</summary>
    [SerializeField] private Vector2 placementExtents = new Vector2(0.8f, 0.3f);

    /// <summary>How far apart (center to center, same real-world-like units as
    /// placementExtents) two items must land to not visually overlap. Set this to
    /// roughly a typical ingredient's own footprint - a fraction of placementExtents
    /// isn't reliable since it doesn't know how big the items themselves are.</summary>
    [SerializeField] private Vector2 minSeparation = new Vector2(0.4f, 0.15f);

    private Transform contentRoot;
    private readonly Dictionary<Carryable, Vector2> occupied = new Dictionary<Carryable, Vector2>();

    /// <summary>Seasonings poured directly into this bowl via a loaded measuring
    /// spoon - e.g. a sauce bowl built up from soy sauce/vinegar/sugar with no
    /// solid ingredient in it at all, distinct from IngredientItem's own
    /// per-ingredient seasoning tracking.</summary>
    private readonly Dictionary<string, int> appliedSeasonings = new Dictionary<string, int>();
    public IReadOnlyDictionary<string, int> AppliedSeasonings => appliedSeasonings;

    public void AddSeasoning(string seasoningName)
    {
        appliedSeasonings.TryGetValue(seasoningName, out int count);
        appliedSeasonings[seasoningName] = count + 1;
    }

    public bool IsFull => occupied.Count >= capacity;

    /// <summary>The burner this vessel is currently sitting on, if any - set by
    /// StoveBurner when the vessel is placed/removed. Whatever's inside gets this
    /// burner (and this vessel's own WokDragHandler, for stir-fry) wired onto its
    /// CookableItem, so cooking progress isn't tied to one fixed burner reference
    /// chosen at design time.</summary>
    public StoveBurner CurrentBurner { get; private set; }

    public void SetBurner(StoveBurner newBurner)
    {
        CurrentBurner = newBurner;
        foreach (Carryable item in occupied.Keys) PropagateBurner(item);
    }

    private void PropagateBurner(Carryable item)
    {
        if (item is IngredientItem ing)
        {
            CookableItem cooked = ing.GetComponent<CookableItem>();
            if (cooked == null) return;
            cooked.SetBurner(CurrentBurner);
            cooked.SetWok(GetComponent<WokDragHandler>());
        }
    }

    private Transform ContentRoot
    {
        get
        {
            if (contentRoot == null)
            {
                // Reuse an existing child (e.g. one baked into the scene at edit time
                // with items already placed in it) rather than creating a duplicate -
                // contentRoot itself is a runtime-only field, so it starts null again
                // after every domain reload / scene load even when the GameObject
                // hierarchy underneath it was already there.
                Transform existing = transform.Find("ContentRoot");
                if (existing != null)
                {
                    contentRoot = existing;
                }
                else
                {
                    var go = new GameObject("ContentRoot");
                    contentRoot = go.transform;
                    contentRoot.SetParent(transform, false);

                    // Cancel out the plate's own (often non-uniform) scale so items
                    // parented here keep their natural size instead of being squashed
                    // into the plate's flattened-oval shape.
                    Vector3 s = transform.lossyScale;
                    contentRoot.localScale = new Vector3(
                        Mathf.Approximately(s.x, 0f) ? 1f : 1f / s.x,
                        Mathf.Approximately(s.y, 0f) ? 1f : 1f / s.y,
                        Mathf.Approximately(s.z, 0f) ? 1f : 1f / s.z);

                    // Cancel out the plate's own rotation too - some plate meshes (an
                    // imported model whose native "up" axis isn't the mesh's front
                    // face) are rotated in the scene to lie flat toward the camera.
                    // PlaceFree spreads items across local X/Y and stacks along local
                    // Z; without this, that X/Y/Z mapping would be skewed by whatever
                    // rotation the plate itself carries, and items dropped anywhere on
                    // screen would land clustered onto a thin sliver instead of
                    // spreading across the plate's visible surface. Keeping contents
                    // screen-aligned also just looks right - a carrot resting on a
                    // tilted plate shouldn't tilt along with the plate's own mesh.
                    contentRoot.rotation = Quaternion.identity;
                }
            }

            return contentRoot;
        }
    }

    protected override void Awake()
    {
        base.Awake();
        ReconcileExistingContents();
        ReconcileExistingLid();
    }

    void Update()
    {
        if (!canHoldWater) return;

        bool canBoil = IsFilledWithWater && !IsHeld && CurrentBurner != null && CurrentBurner.IsOn;
        float timeToBoil = HasLid ? timeToBoilWithLid : timeToBoilNoLid;
        if (!canBoil)
        {
            boilProgress = 0f;
            SetBoiling(false);
        }
        else
        {
            boilProgress += Time.deltaTime;
            if (boilProgress >= timeToBoil) SetBoiling(true);
        }

        UpdateWaterLook(canBoil ? Mathf.Clamp01(boilProgress / Mathf.Max(timeToBoil, 0.01f)) : 0f);
    }

    /// <summary>Eases the water shader's heat (burner glow, first small bubbles)
    /// and boil (full rolling bubbles) toward the vessel's actual state, so the
    /// water visibly warms up and calms down again instead of snapping.</summary>
    private void UpdateWaterLook(float targetHeat)
    {
        if (waterMaterialInstance == null || WaterAmount <= 0f) return;

        float step = waterLookSpeed * Time.deltaTime;
        float newHeat = Mathf.MoveTowards(shownHeat, targetHeat, step);
        float newBoil = Mathf.MoveTowards(shownBoil, IsBoiling ? 1f : 0f, step * 2f);
        // Sloshes hard right after filling / while being carried, then settles.
        float newSlosh = IsHeld ? Mathf.Max(shownSlosh, 0.7f)
                                : Mathf.MoveTowards(shownSlosh, idleSlosh, 0.35f * Time.deltaTime);
        if (newHeat == shownHeat && newBoil == shownBoil && newSlosh == shownSlosh) return;

        shownHeat = newHeat;
        shownBoil = newBoil;
        shownSlosh = newSlosh;
        waterMaterialInstance.SetFloat(HeatId, shownHeat);
        waterMaterialInstance.SetFloat(BoilId, shownBoil);
        waterMaterialInstance.SetFloat(SloshId, shownSlosh);
    }

    private void SetBoiling(bool boiling)
    {
        if (IsBoiling == boiling) return;
        IsBoiling = boiling;

        if (boiling)
        {
            if (bubbleInstance == null && bubbleEffectPrefab != null && waterVisual != null)
            {
                bubbleInstance = Instantiate(bubbleEffectPrefab, waterVisual.transform);
                bubbleInstance.transform.localPosition = Vector3.zero;
                bubbleInstance.transform.localRotation = Quaternion.identity;
            }
            bubbleInstance?.SetActive(true);
        }
        else
        {
            bubbleInstance?.SetActive(false);
        }
    }

    /// <summary>A lid resting on this vessel at edit time (parented directly
    /// under it, not under ContentRoot - it's not "contents") needs its
    /// CurrentContainer/currentLid bookkeeping set up the same way pre-placed
    /// ingredients get it, or picking it up wouldn't know to clear this vessel's
    /// lid slot.</summary>
    private void ReconcileExistingLid()
    {
        foreach (Transform child in transform)
        {
            PotLid lid = child.GetComponent<PotLid>();
            if (lid == null) continue;

            currentLid = lid;
            lid.CurrentContainer = this;
            break;
        }
    }

    /// <summary>Picks up any items already sitting under ContentRoot at startup (e.g.
    /// ingredients arranged on this plate at edit time, like the exam's pre-portioned
    /// tray) into the occupied bookkeeping, so capacity/collision-avoidance accounts
    /// for them from the first frame instead of only learning about them once each is
    /// picked up and re-dropped.</summary>
    private void ReconcileExistingContents()
    {
        Transform root = ContentRoot;
        foreach (Transform child in root)
        {
            Carryable c = child.GetComponent<Carryable>();
            if (c == null || occupied.ContainsKey(c)) continue;

            Vector2 spot = new Vector2(child.localPosition.x, child.localPosition.y);
            occupied[c] = spot;
            c.CurrentContainer = this;
            PropagateBurner(c);

            // Edit-time-authored children may have been positioned with an older/flat
            // z-offset that the sphere-bulge-aware SurfaceZOffset now supersedes -
            // recompute so they aren't buried behind the container's own geometry.
            Vector3 lp = child.localPosition;
            lp.z = SurfaceZOffset(spot);
            child.localPosition = lp;
        }
    }

    /// <summary>A plate still holding ingredients shouldn't be pickup-able itself -
    /// clicking it with an empty hand would otherwise carry off the whole plate
    /// (and everything on it) instead of letting the player take ingredients off
    /// one at a time. Only once every ingredient has been removed does the plate
    /// itself become a normal Carryable again.</summary>
    protected override bool OnClickedWhileHandEmpty()
    {
        return occupied.Count > 0;
    }

    protected override void OnClickedWhileHandFull(Carryable held)
    {
        if (held is ToolItem knife && knife.Kind == ToolKind.Knife)
        {
            ScoopFromBoard();
            return;
        }

        if (held is PotLid lid)
        {
            PlaceLid(lid);
            return;
        }

        if (held is ToolItem spoon && spoon.Kind == ToolKind.MeasuringSpoon && spoon.IsSpoonLoaded)
        {
            AddSeasoning(spoon.LoadedSeasoning);
            spoon.ConsumeSeasoning();
            return;
        }

        // Using a bottle on a bowl measures one spoonful into the measuring
        // spoon (bottle back to the shelf, loaded spoon in hand) - the spoon
        // branch above then adds it on the next click.
        if (held is SeasoningBottle bottle)
        {
            bottle.TryScoopWithSpoon();
            return;
        }

        // A towel (wrapping an ingredient, or empty) needs somewhere to be set
        // down too - a plate/bowl's own accepts policy (usually IngredientOnly)
        // would otherwise silently reject the ToolItem itself and leave it
        // stuck in hand, since this isn't "adding the towel as bowl content".
        // Only the wrapping case matters for handing an ingredient off, but an
        // empty towel needs a resting spot just as much or it can never be set
        // down again once picked up with nothing to wrap.
        if (held is ToolItem towel && towel.IsTowelKind)
        {
            // A water-filled vessel gets wiped dry instead of having the towel
            // set down into it - "접시 물기닦기": drying off a washed bowl/plate
            // is a real step, and dropping the towel into standing water instead
            // would be an odd result of the same click.
            if (IsFilledWithWater)
            {
                SetFilledWithWater(false);
                ProcessStageManager.Instance?.MarkWiped();
                return;
            }

            if (HandCarry.Instance.PlaceAtAnchor(transform)) towel.CurrentContainer = this;
            return;
        }

        if (IsFull) return;
        if (!Accepts(held)) return;

        HandCarry.Instance.PlaceAtBowl(this);
    }

    public bool Accepts(Carryable c)
    {
        switch (accepts)
        {
            case SlotAccepts.IngredientOnly: return c is IngredientItem;
            case SlotAccepts.ToolOnly: return c is ToolItem;
            default: return true;
        }
    }

    public override bool CanAcceptDrop(Carryable item)
    {
        if (item is ToolItem knife && knife.Kind == ToolKind.Knife) return CanScoopFromBoard();
        if (item is PotLid) return currentLid == null;
        if (item is ToolItem spoon && spoon.Kind == ToolKind.MeasuringSpoon && spoon.IsSpoonLoaded) return true;
        if (item is SeasoningBottle) return true;
        if (item is ToolItem towel && towel.IsTowelKind) return true;
        return !IsFull && Accepts(item);
    }

    /// <summary>Sits any pot/pan lid on top of this vessel's own actual render
    /// bounds (not a fixed offset) so it works the same for every vessel shape -
    /// generic on purpose, since more lidded dishes are coming later.</summary>
    private PotLid currentLid;

    public bool HasLid => currentLid != null;

    private void PlaceLid(PotLid lid)
    {
        if (currentLid != null) return;

        Bounds worldBounds = GetComponent<Renderer>().bounds;
        Vector3 topWorld = new Vector3(worldBounds.center.x, worldBounds.center.y + worldBounds.extents.y * 0.85f, worldBounds.center.z);
        Vector3 topLocal = transform.InverseTransformPoint(topWorld);

        if (!HandCarry.Instance.PlaceAtFreeLocalPosition(transform, topLocal)) return;

        currentLid = lid;
        lid.CurrentContainer = this;
    }

    private bool CanScoopFromBoard()
    {
        IngredientItem cut = CuttingBoardController.Instance?.Current as IngredientItem;
        return cut != null && cut.CurrentState == IngredientItem.State.Cut && !IsFull && Accepts(cut);
    }

    /// <summary>Using the flat of the knife to push cut ingredients into a bowl - the
    /// real-kitchen move that skips having to set the knife down first just to free a
    /// hand for the ingredient. Dragging the (still-held) knife onto a bowl scoops
    /// whatever's sitting cut on the cutting board straight in.</summary>
    private void ScoopFromBoard()
    {
        if (!CanScoopFromBoard()) return;

        CuttingBoardController board = CuttingBoardController.Instance;
        IngredientItem cut = (IngredientItem)board.Current;

        Vector3 dropPos = cut.transform.position;
        board.Release(cut);
        cut.CurrentContainer = null;

        PlaceFree(cut, dropPos);
        cut.transform.localScale = cut.BaseLocalScale;
        cut.CurrentContainer = this;
        cut.OnPlaced();
    }

    /// <summary>Parents the item under this plate at (a bounds-clamped, collision-
    /// avoided version of) wherever it currently sits in the world, so it lands
    /// freely on the plate's surface instead of snapping to a fixed slot.</summary>
    public void PlaceFree(Carryable item, Vector3 worldDropPosition)
    {
        Transform root = ContentRoot;
        item.transform.SetParent(root, false);

        Vector3 desired3 = root.InverseTransformPoint(worldDropPosition);
        Vector2 desired = new Vector2(
            Mathf.Clamp(desired3.x, -placementExtents.x, placementExtents.x),
            Mathf.Clamp(desired3.y, -placementExtents.y, placementExtents.y));

        Vector2 spot = FindFreeSpot(desired);
        item.transform.localPosition = new Vector3(spot.x, spot.y, SurfaceZOffset(spot));

        occupied[item] = spot;
        PropagateBurner(item);
    }

    /// <summary>How far in front of this container's own center an item at the given
    /// (x,y) offset must sit to clear the container's own surface. Some plate meshes
    /// are a full sphere flattened into a dish shape, not a flat disc, so their front
    /// face bulges toward the camera - most near the center, less near the rim. A flat
    /// offset from the transform's own z (the old approach) only cleared that bulge
    /// right at the rim; everywhere closer to center it buried the item behind the
    /// plate's own geometry, which is why pre-placed ingredients disappeared.
    /// Uses the plate's actual world-space render bounds rather than assuming a unit
    /// sphere (radius 0.5) mesh, so this also works for an imported plate model with
    /// its own real proportions - a thin, wide mesh barely bulges at all, which is
    /// the right behavior for something that's actually closer to a flat disc.</summary>
    private float SurfaceZOffset(Vector2 localXY)
    {
        Bounds worldBounds = GetComponent<Renderer>().bounds;
        float a = Mathf.Max(worldBounds.extents.x, 0.001f);
        float b = Mathf.Max(worldBounds.extents.y, 0.001f);
        float c = worldBounds.extents.z;

        float nx = localXY.x / a;
        float ny = localXY.y / b;
        float underSqrt = 1f - nx * nx - ny * ny;
        float bulge = underSqrt > 0f ? c * Mathf.Sqrt(underSqrt) : 0f;

        // A flat base offset (not just the tiny per-item stacking increment) keeps every
        // item - including the very first one placed - solidly in front of the plate's
        // own collider, so a raycast at an item's position always resolves to the item
        // rather than the plate underneath it.
        return -(bulge + 0.03f + 0.01f * occupied.Count);
    }

    private Vector2 FindFreeSpot(Vector2 desired)
    {
        if (IsFreeSpot(desired)) return desired;

        Vector2 step = minSeparation;
        for (int ring = 1; ring <= 8; ring++)
        {
            float radius = Mathf.Max(step.x, step.y) * ring;
            int samples = 6 * ring;
            for (int i = 0; i < samples; i++)
            {
                float angle = (Mathf.PI * 2f / samples) * i;
                Vector2 candidate = desired + new Vector2(Mathf.Cos(angle) * step.x, Mathf.Sin(angle) * step.y) * ring;
                candidate.x = Mathf.Clamp(candidate.x, -placementExtents.x, placementExtents.x);
                candidate.y = Mathf.Clamp(candidate.y, -placementExtents.y, placementExtents.y);
                if (IsFreeSpot(candidate)) return candidate;
            }
        }

        return desired; // plate is packed tight enough that nothing opened up - overlap rather than get stuck
    }

    private bool IsFreeSpot(Vector2 p)
    {
        Vector2 sep = minSeparation;
        foreach (Vector2 occ in occupied.Values)
        {
            float dx = (p.x - occ.x) / Mathf.Max(sep.x, 0.0001f);
            float dy = (p.y - occ.y) / Mathf.Max(sep.y, 0.0001f);
            if (dx * dx + dy * dy < 1f) return false;
        }
        return true;
    }

    public void Release(Carryable item)
    {
        if ((object)item == currentLid)
        {
            currentLid = null;
            return;
        }

        occupied.Remove(item);

        // Taken back out of the vessel - no longer sitting over any burner,
        // however this vessel itself is currently placed.
        if (item is IngredientItem ing)
        {
            CookableItem cooked = ing.GetComponent<CookableItem>();
            if (cooked != null) { cooked.SetBurner(null); cooked.SetWok(null); }
        }
    }

    /// <summary>Fills (or empties) this vessel all at once - emptying is the
    /// towel wipe; filling instantly is kept for any caller that just wants it
    /// full. The faucet fills gradually through AddWater instead.</summary>
    public void SetFilledWithWater(bool filled)
    {
        if (!canHoldWater) return;
        SetWaterAmount(filled ? 1f : 0f);
    }

    /// <summary>Called every frame by a running WaterTap while this vessel sits
    /// (or is held) under its stream - the water visibly rises to half full
    /// over secondsToFill, then stops.</summary>
    public void AddWater(float deltaTime)
    {
        if (!canHoldWater || WaterAmount >= 1f) return;
        SetWaterAmount(WaterAmount + deltaTime / Mathf.Max(secondsToFill, 0.01f));
    }

    private void SetWaterAmount(float amount)
    {
        float previous = WaterAmount;
        WaterAmount = Mathf.Clamp01(amount);
        IsFilledWithWater = WaterAmount >= 1f;

        if (!IsFilledWithWater)
        {
            boilProgress = 0f;
            SetBoiling(false);
        }

        if (WaterAmount > 0f) EnsureWaterVisual();

        // Water just started going in - fresh water sloshes, then settles.
        if (previous <= 0f && WaterAmount > 0f)
        {
            shownHeat = 0f;
            shownBoil = 0f;
            shownSlosh = 1f;
            if (waterMaterialInstance != null)
            {
                waterMaterialInstance.SetFloat(HeatId, 0f);
                waterMaterialInstance.SetFloat(BoilId, 0f);
                waterMaterialInstance.SetFloat(SloshId, shownSlosh);
            }
        }

        if (waterVisual == null) return;
        waterVisual.SetActive(WaterAmount > 0f);

        // Surface rises from just above the bottom to the full line, spreading
        // out a little as it goes (a thin puddle first, then the full surface).
        waterVisual.transform.localPosition = Vector3.Lerp(waterBottomLocal, waterTopLocal, WaterAmount);
        float d = waterDiameter * Mathf.Lerp(0.75f, 1f, WaterAmount);
        waterVisual.transform.localScale = new Vector3(d, waterThickness, d);
    }

    private void EnsureWaterVisual()
    {
        if (waterVisual != null) return;

        waterVisual = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        waterVisual.name = "WaterFill";
        Object.DestroyImmediate(waterVisual.GetComponent<Collider>());

        // Laid out in the vessel's own local space (model Y = up), so the
        // surface sits level inside the mouth and tilts with the vessel -
        // a pot angled toward the camera shows an oval of water inside its
        // rim instead of a camera-facing circle floating off to one side.
        Bounds lb = GetComponent<Renderer>().localBounds;
        FindBodyCircle(lb, out Vector3 center, out float bodyRadius);
        center += waterLocalOffset;

        waterBottomLocal = new Vector3(center.x, lb.min.y + lb.size.y * 0.08f + waterLocalOffset.y, center.z);
        waterTopLocal = new Vector3(center.x, lb.min.y + lb.size.y * fullWaterLevel + waterLocalOffset.y, center.z);
        waterDiameter = bodyRadius * 2f * waterInnerRatio;
        waterThickness = lb.size.y * 0.002f;

        waterVisual.transform.SetParent(transform, false);
        waterVisual.transform.localRotation = Quaternion.identity;

        var rend = waterVisual.GetComponent<Renderer>();
        rend.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        rend.receiveShadows = false;

        Shader waterShader = Shader.Find("Kitchen/PotWater");
        if (waterMaterial != null) waterMaterialInstance = new Material(waterMaterial);
        else if (waterShader != null) waterMaterialInstance = new Material(waterShader);

        if (waterMaterialInstance != null)
        {
            rend.material = waterMaterialInstance;
        }
        else
        {
            // Shader missing (e.g. stripped from a build) - plain blue tint.
            rend.material = new Material(rend.sharedMaterial.shader);
            rend.material.color = new Color(0.3f, 0.55f, 0.9f);
        }
    }

    /// <summary>The round body of this vessel in its own local XZ plane (model Y
    /// = up), ignoring any handle. A handle stretches the bounds along its own
    /// direction, so the bounds center sits off toward the handle and the water
    /// used to spill over the rim on that side. With a readable mesh, a few
    /// mean-shift steps over the vertices pull the center onto the body itself
    /// (the handle's vertices fall outside the body radius and drop out);
    /// otherwise the model's pivot - normally the body's center for a pot - is
    /// used along the handle's axis, and waterLocalOffset can nudge it.</summary>
    private void FindBodyCircle(Bounds localBounds, out Vector3 center, out float radius)
    {
        center = localBounds.center;
        float ex = localBounds.extents.x;
        float ez = localBounds.extents.z;
        // Smaller of the two horizontal extents - the handle only lengthens one.
        radius = Mathf.Min(ex, ez);

        MeshFilter mf = GetComponent<MeshFilter>();
        Mesh mesh = mf != null ? mf.sharedMesh : null;
        if (mesh == null || !mesh.isReadable)
        {
            if (Mathf.Abs(ex - ez) > radius * 0.1f)
            {
                if (ex > ez) center.x = Mathf.Clamp(0f, localBounds.min.x + radius, localBounds.max.x - radius);
                else center.z = Mathf.Clamp(0f, localBounds.min.z + radius, localBounds.max.z - radius);
            }
            return;
        }

        Vector3[] verts = mesh.vertices;
        if (verts.Length == 0) return;

        Vector2 c = new Vector2(center.x, center.z);
        float window = radius * 1.05f;
        for (int iter = 0; iter < 8; iter++)
        {
            Vector2 sum = Vector2.zero;
            int count = 0;
            foreach (Vector3 v in verts)
            {
                Vector2 w = new Vector2(v.x, v.z);
                if ((w - c).sqrMagnitude > window * window) continue;
                sum += w;
                count++;
            }
            if (count == 0) break;
            c = sum / count;
        }

        float maxDist = 0f;
        foreach (Vector3 v in verts)
        {
            float d = (new Vector2(v.x, v.z) - c).magnitude;
            if (d <= window && d > maxDist) maxDist = d;
        }
        if (maxDist > 0f) radius = maxDist;
        center.x = c.x;
        center.z = c.y;
    }

    /// <summary>While this bowl itself is being dragged, its contents ride along as
    /// attached baggage - if their colliders stay active, a raycast aimed at wherever
    /// the player drops the bowl can hit an ingredient sitting on it instead of the
    /// actual destination underneath, leaving the bowl stuck in hand. Called by
    /// Carryable around its own drag collider toggle.</summary>
    public void SetContentsCollidersEnabled(bool enabled)
    {
        foreach (Carryable item in occupied.Keys)
        {
            Collider c = item.GetComponent<Collider>();
            if (c != null) c.enabled = enabled;
        }
    }
}

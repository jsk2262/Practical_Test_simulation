using UnityEngine;

public class WashBasin : Interactable
{
    protected override void Activate()
    {
        HandCarry hand = HandCarry.Instance;
        if (hand?.Current is IngredientItem ing)
        {
            CookableItem cooked = ing.GetComponent<CookableItem>();
            if (cooked != null && cooked.CurrentStage == CookableItem.Stage.Done)
            {
                cooked.ColdShock();
            }
            else if (ing.CurrentState == IngredientItem.State.Raw)
            {
                if (ing.NeedsSoaking) ing.StartSoaking();
                else
                {
                    ing.Wash();
                    HandController.Instance?.PlayWashGesture();
                }
            }
        }
        else if (hand?.Current is ToolItem tool && tool.Kind == ToolKind.Knife)
        {
            tool.GetComponent<HygieneTracker>()?.Wash();
        }
        else if (hand?.Current is ToolItem towel && towel.IsTowelKind)
        {
            // "손 씻기": drying hands with the towel right at the sink, the
            // natural follow-up to the empty-handed wash gesture below.
            HandController.Instance?.PlayWashGesture();

            // A wrapped towel needs somewhere to unwrap, and a plain one
            // (e.g. picked up with nothing on the board to wrap) needs
            // somewhere to rest too - without the plain case, a towel picked
            // up empty-handed had nowhere it could ever be set back down
            // again, leaving it stuck in hand for the rest of the session.
            HandCarry.Instance.PlaceAtAnchor(transform);
            towel.CurrentContainer = null;
        }
        else if (hand?.Current is MovableBowl bowl)
        {
            // Just resting the bowl at the sink (e.g. to fill it under the faucet
            // right there) - not itself a wash action, unlike the ingredient/knife
            // cases above.
            HandCarry.Instance.PlaceAtAnchor(transform);
            bowl.CurrentContainer = null;
        }
        else if (hand?.Current is PotLid lid)
        {
            // A lid taken off one pot and not immediately handed to another
            // needs somewhere to rest too, or it's stuck in hand for good -
            // same reasoning as the empty-towel fix above.
            HandCarry.Instance.PlaceAtAnchor(transform);
            lid.CurrentContainer = null;
        }
        else if (hand?.Current == null)
        {
            // Clicking the sink with nothing in hand is the player washing their
            // own hands - the real exam's opening step, and one of the 순서도
            // planning cards, but until now had no actual action behind it.
            HandController.Instance?.PlayWashGesture();
        }
    }

    public override bool CanAcceptDrop(Carryable item)
    {
        if (item is IngredientItem ing)
        {
            CookableItem cooked = ing.GetComponent<CookableItem>();
            if (cooked != null && cooked.CurrentStage == CookableItem.Stage.Done) return true;
            return ing.CurrentState == IngredientItem.State.Raw;
        }

        if (item is ToolItem tool) return tool.Kind == ToolKind.Knife || tool.IsTowelKind;
        if (item is PotLid) return true;

        return item is MovableBowl;
    }
}
